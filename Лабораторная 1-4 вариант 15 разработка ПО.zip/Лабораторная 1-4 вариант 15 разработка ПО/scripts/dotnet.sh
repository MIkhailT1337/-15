#!/bin/sh
set -eu
script_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
if command -v dotnet >/dev/null 2>&1; then
    exec dotnet "$@"
fi
runtime_path="$script_root/../../work/dotnet/dotnet"
if [ -x "$runtime_path" ]; then
    DOTNET_ROOT=$(CDPATH= cd -- "$(dirname -- "$runtime_path")" && pwd)
    export DOTNET_ROOT
    exec "$runtime_path" "$@"
fi
echo 'Установите .NET SDK 10: https://dotnet.microsoft.com/download/dotnet/10.0' >&2
exit 1
