#!/bin/sh
set -eu
script_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
case "${1:-}" in
  1) project='Labs/Lab01-UI/ContactManager.csproj' ;;
  2) project='Labs/Lab02-ADO.NET/ContactManager.csproj' ;;
  3) project='Labs/Lab03-EFCore/ContactManager.csproj' ;;
  4) project='Labs/Lab04-AsyncCSV/CsvBatch.csproj' ;;
  *) echo 'Использование: ./scripts/run.sh 1|2|3|4' >&2; exit 2 ;;
esac
exec "$script_root/scripts/dotnet.sh" run --project "$script_root/$project"
