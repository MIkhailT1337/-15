#!/bin/sh
set -eu
script_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
for project in 'Labs/Lab01-UI/Tests/ContactManager.Checks.csproj' 'Labs/Lab02-ADO.NET/Tests/ContactManager.Checks.csproj' 'Labs/Lab03-EFCore/Tests/ContactManager.Checks.csproj' 'Labs/Lab04-AsyncCSV/Tests/CsvBatch.Checks.csproj'; do
  "$script_root/scripts/dotnet.sh" run --project "$script_root/$project"
done
