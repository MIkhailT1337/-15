#!/usr/bin/env python3
"""Настройка локальной учебной БД. Пароли не выводятся и не входят в Git."""
import json, os, pathlib, secrets, subprocess, time
root = pathlib.Path(__file__).resolve().parents[2]
project = root / 'Labs/Lab02-ADO.NET'
docker = '/Applications/Docker.app/Contents/Resources/bin/docker'
private = root / '.sql-local'
private.mkdir(exist_ok=True, mode=0o700)
secret_file = private / 'credentials.json'
if secret_file.exists():
    passwords = json.loads(secret_file.read_text())
else:
    passwords = {key: 'Lab15!'+secrets.token_hex(18) for key in ('sa','app')}
    secret_file.touch(mode=0o600)
    secret_file.write_text(json.dumps(passwords))
env = dict(os.environ, PATH=str(pathlib.Path(docker).parent)+':'+os.environ['PATH'])
def run(args, **kwargs):
    return subprocess.run([docker, *args], env=env, check=True, **kwargs)
exists = subprocess.run([docker, 'container', 'inspect', 'variant15-sql'], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
if not exists:
    env['MSSQL_SA_PASSWORD'] = passwords['sa']
    run(['run','-d','--name','variant15-sql','--platform','linux/amd64',
         '--restart','unless-stopped','-p','127.0.0.1:1433:1433',
         '-e','ACCEPT_EULA=Y','-e','MSSQL_PID=Developer','-e','MSSQL_SA_PASSWORD',
         '-v','variant15-sql-data:/var/opt/mssql','mcr.microsoft.com/mssql/server:2022-latest'], stdout=subprocess.DEVNULL)
else:
    run(['start','variant15-sql'], stdout=subprocess.DEVNULL)
# Повторный запуск безопасен: схема не удаляет существующие контакты.
env['SQLCMDPASSWORD'] = passwords['sa']
for attempt in range(60):
    ready = subprocess.run([docker,'exec','-e','SQLCMDPASSWORD','variant15-sql','/opt/mssql-tools18/bin/sqlcmd','-S','localhost','-U','sa','-C','-b','-Q','SELECT 1'], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if ready.returncode == 0: break
    time.sleep(1)
else:
    raise SystemExit('SQL Server не готов. Проверьте docker logs variant15-sql.')
sql = (project/'Database/01-schema.sql').read_text()+'\nGO\n'
sql += (project/'Database/02-user.sql').read_text().replace('REPLACE_WITH_STRONG_PASSWORD', passwords['app'], 1)
run(['exec','-i','-e','SQLCMDPASSWORD','variant15-sql','/opt/mssql-tools18/bin/sqlcmd','-S','localhost','-U','sa','-C','-b'], input=sql, text=True)
config = project/'database.local.json'
config.touch(mode=0o600, exist_ok=True)
config.write_text(json.dumps({'ConnectionString':f"Server=tcp:127.0.0.1,1433;Database=ContactManagerDb;User ID=contact_app;Password={passwords['app']};Encrypt=True;TrustServerCertificate=True;Connect Timeout=5"}, indent=2)+'\n')
print('База ContactManagerDb и подключение ЛР 2 настроены.')
