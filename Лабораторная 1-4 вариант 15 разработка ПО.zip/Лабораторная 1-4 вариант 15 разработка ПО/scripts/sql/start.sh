#!/bin/sh
set -eu
docker=/Applications/Docker.app/Contents/Resources/bin/docker
if ! "$docker" info >/dev/null 2>&1; then
  echo 'Сначала открой Docker в папке «Программы» и дождись Engine running.'
  exit 1
fi
"$docker" start variant15-sql
printf 'SQL Server запущен. Теперь запускай ЛР 2.\n'
