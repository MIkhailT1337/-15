# Лабораторные работы по C#

Студент: Танганов Михаил Александрович.

Вариант 15. Интерфейс приложений выполнен на Avalonia для macOS, целевая платформа — .NET 10.

| Работа | Проект | Содержание |
|---|---|---|
| 1 | Labs/Lab01-UI | Менеджер контактов, события, валидация и коллекция |
| 2 | Labs/Lab02-ADO.NET | SQL Server, ADO.NET, CRUD, присоединённая и отсоединённая модели |
| 3 | Labs/Lab03-EFCore | Entity Framework Core, Code First, миграции и SQLite |
| 4 | Labs/Lab04-AsyncCSV | Асинхронная обработка CSV, параллелизм, отмена и JSON |

## Структура

- Labs — исходный код, тесты и учебные данные.
- Reports — четыре отчёта и общий документ со скриншотами интерфейса и кода.
- Prototype — макет интерфейса Draw.io.
- Verification — результаты проверок.
- scripts — команды сборки, запуска и подготовки локальной базы.

## Технологии

C#, Avalonia, Microsoft.Data.SqlClient, System.Data, Entity Framework Core, SQLite, SQL Server 2022 Developer, TPL.

В ЛР 2 используется база ContactManagerDb, процедуры ContactList, ContactInsert, ContactUpdate, ContactDelete, функция ImportanceRank, представление ContactOverview и роль ContactManagerAppRole. Строка подключения задаётся через CONTACT_MANAGER_SQL или database.local.json. Локальные пароли и базы исключены из репозитория.

## Проверка

10 ноября 2026 года прошли 60 проверок: 7 для ЛР 1, 19 для ЛР 2, 16 для ЛР 3, 18 для ЛР 4. Шесть интеграционных сценариев ЛР 2 выполнены на SQL Server. Интерфейс проверен в Avalonia.Headless, данные ЛР 3 — на реальной SQLite базе, ЛР 4 — на реальных CSV. Дополнительный SQL Server провайдер ЛР 3 не проходил серверную проверку.

SQL Server развёрнут в Docker с томом variant15-sql-data и портом 127.0.0.1:1433. На Apple Silicon используется эмуляция amd64, официально не поддерживаемая Microsoft.
