namespace ContactManager;

public sealed record Contact(string FullName, string Category, string Importance, string[] Tags)
{
    public string TagsText => Tags.Length == 0 ? "Без пометок" : string.Join(", ", Tags);
    public string Summary => $"{Category} · {Importance} важность · {TagsText}";
}
