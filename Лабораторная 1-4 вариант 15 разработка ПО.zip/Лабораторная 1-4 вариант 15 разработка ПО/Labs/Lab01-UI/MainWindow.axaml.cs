using System.Collections.ObjectModel;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media;

namespace ContactManager;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<Contact> contacts = new();
    private bool isReady;

    public MainWindow()
    {
        InitializeComponent();
        ContactsList.ItemsSource = contacts;
        isReady = true;
        UpdatePreview();
    }

    private string[] NameParts() => (FullNameBox.Text ?? "")
        .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);

    // Проверяем обязательное поле, не ограничивая алфавит имени.
    private bool ValidateName()
    {
        bool valid = NameParts().Length >= 2;
        FullNameBox.Classes.Set("error", !valid);
        NameError.IsVisible = !valid;
        return valid;
    }

    private Contact ReadContact()
    {
        var tags = new List<string>();
        if (CarCheck.IsChecked == true) tags.Add("Автомобиль");
        if (SportCheck.IsChecked == true) tags.Add("Спорт");
        if (ItCheck.IsChecked == true) tags.Add("IT");
        string category = (CategoryBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Друзья";
        string importance = HighRadio.IsChecked == true ? "Высокая"
            : LowRadio.IsChecked == true ? "Низкая" : "Средняя";
        return new Contact(string.Join(" ", NameParts()), category, importance, tags.ToArray());
    }

    private void OnSaveClick(object? sender, RoutedEventArgs e)
    {
        if (!ValidateName())
        {
            ShowStatus("Введите имя и фамилию. Контакт не сохранён.", true);
            FullNameBox.Focus();
            return;
        }

        // Каждая запись сохраняет собственный снимок выбранных параметров.
        Contact contact = ReadContact();
        contacts.Add(contact);
        ContactsList.SelectedItem = contact;
        ResetForm();
        UpdateCount();
        ShowStatus($"Контакт «{contact.FullName}» сохранён. Контактов: {contacts.Count}.");
    }

    private void OnClearClick(object? sender, RoutedEventArgs e)
    {
        ResetForm();
        ShowStatus("Форма очищена. Сохранённые контакты остались в списке.");
    }

    private void ResetForm()
    {
        isReady = false;
        FullNameBox.Text = "";
        CategoryBox.SelectedIndex = 0;
        CarCheck.IsChecked = SportCheck.IsChecked = ItCheck.IsChecked = false;
        MediumRadio.IsChecked = true;
        FullNameBox.Classes.Set("error", false);
        NameError.IsVisible = false;
        isReady = true;
        UpdatePreview();
        FullNameBox.Focus();
    }

    private void OnDeleteClick(object? sender, RoutedEventArgs e)
    {
        if (ContactsList.SelectedItem is not Contact contact) return;
        contacts.Remove(contact);
        ContactsList.SelectedItem = null;
        UpdateSelection();
        UpdateCount();
        ShowStatus($"Контакт «{contact.FullName}» удалён. Контактов: {contacts.Count}.");
    }

    private void OnContactSelected(object? sender, SelectionChangedEventArgs e)
    {
        if (isReady) UpdateSelection();
    }

    private void UpdateSelection()
    {
        var contact = ContactsList.SelectedItem as Contact;
        DeleteButton.IsEnabled = contact is not null;
        DetailsText.Text = contact is null ? "Выберите контакт, чтобы увидеть сведения"
            : $"{contact.FullName}\nКатегория: {contact.Category}\nВажность: {contact.Importance}\nПометки: {contact.TagsText}";
    }

    private void UpdateCount()
    {
        CountText.Text = $"Контактов: {contacts.Count}";
        EmptyText.IsVisible = contacts.Count == 0;
    }

    private void OnNameChanged(object? sender, TextChangedEventArgs e)
    {
        if (!isReady) return;
        if (NameError.IsVisible) ValidateName();
    }

    private void OnNameLostFocus(object? sender, RoutedEventArgs e)
    {
        if (isReady && !string.IsNullOrWhiteSpace(FullNameBox.Text)) ValidateName();
    }

    // RoutedEventArgs подходит как для изменения флажков, так и для выбора категории.
    private void OnOptionsChanged(object? sender, RoutedEventArgs e)
    {
        if (isReady) UpdatePreview();
    }

    private void UpdatePreview() => PreviewText.Text = $"Будет сохранено: {ReadContact().Summary}";

    private void ShowStatus(string message, bool error = false)
    {
        StatusText.Text = message;
        StatusText.Foreground = error ? Brushes.Firebrick : Brushes.SeaGreen;
    }
}
