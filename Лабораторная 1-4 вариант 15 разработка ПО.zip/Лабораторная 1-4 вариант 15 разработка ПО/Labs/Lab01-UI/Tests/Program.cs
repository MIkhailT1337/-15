using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Interactivity;
using Avalonia.VisualTree;
using ContactManager;

AppBuilder.Configure<App>().UseSkia().WithInterFont().UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false }).SetupWithoutStarting();
var window = new MainWindow();
window.Show();
T Find<T>(string name) where T : Control => window.FindControl<T>(name)!;
void Check(bool value, string name) { if (!value) throw new Exception(name); Console.WriteLine("PASS: " + name); }
void Click(string name)
{
    var button = window.GetVisualDescendants().OfType<Button>().Single(b => Equals(b.Content, name));
    button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
}
void Capture(string name)
{
    if (!args.Contains("--capture")) return;
    Avalonia.Threading.Dispatcher.UIThread.RunJobs();
    Avalonia.Headless.AvaloniaHeadlessPlatform.ForceRenderTimerTick();
    using var frame = window.CaptureRenderedFrame();
    Directory.CreateDirectory("Images");
    frame!.Save(Path.Combine("Images", name + ".png"));
}
Capture("app-empty");
var list = Find<ListBox>("ContactsList");
Click("Сохранить контакт");
Check(list.ItemCount == 0 && Find<TextBlock>("NameError").IsVisible, "empty input rejected");
Capture("app-error");
Find<TextBox>("FullNameBox").Text = "Анна";
Click("Сохранить контакт");
Check(list.ItemCount == 0, "incomplete name rejected");
Find<TextBox>("FullNameBox").Text = "  Анна   Смирнова  ";
Find<ComboBox>("CategoryBox").SelectedIndex = 1;
Find<CheckBox>("SportCheck").IsChecked = true;
Find<CheckBox>("ItCheck").IsChecked = true;
Find<RadioButton>("HighRadio").IsChecked = true;
Click("Сохранить контакт");
var contact = (Contact)list.SelectedItem!;
Check(contact.FullName == "Анна Смирнова" && contact.Category == "Коллеги" && contact.Importance == "Высокая" && contact.Tags.SequenceEqual(new[]{"Спорт", "IT"}), "all selected fields saved and whitespace normalized");
Check(Find<TextBox>("FullNameBox").Text == "" && Find<RadioButton>("MediumRadio").IsChecked == true && Find<CheckBox>("ItCheck").IsChecked == false, "form reset");
Check(Find<TextBlock>("CountText").Text == "Контактов: 1" && Find<TextBlock>("DetailsText").Text!.Contains("Анна Смирнова"), "counter and selected details updated");
Capture("app-saved");
Click("Очистить");
Check(list.ItemCount == 1, "clear preserves contacts");
Click("Удалить выбранный");
Check(list.ItemCount == 0 && !Find<Button>("DeleteButton").IsEnabled && Find<TextBlock>("EmptyText").IsVisible, "delete restores empty state");
window.Close();
