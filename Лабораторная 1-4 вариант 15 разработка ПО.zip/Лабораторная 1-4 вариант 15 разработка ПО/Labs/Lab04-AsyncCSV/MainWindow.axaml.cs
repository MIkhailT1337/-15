using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using CsvBatch.Core;

namespace CsvBatch;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<FileItem> files = new();
    private readonly Dictionary<string, FileItem> lookup = new(StringComparer.Ordinal);
    private readonly DispatcherTimer timer = new() { Interval = TimeSpan.FromMilliseconds(100) };
    private readonly Stopwatch elapsed = new();
    private CancellationTokenSource? cancellation;
    private bool running, closeRequested;
    private int probeCount, ticks, runId;
    public Task? ActiveRun { get; private set; }

    public MainWindow()
    {
        InitializeComponent();
        FilesList.ItemsSource = files;
        FolderBox.Text = Path.Combine(AppContext.BaseDirectory, "Samples");
        timer.Tick += (_, _) =>
        {
            ticks++;
            HeartbeatText.Text = $"Счётчик UI: {ticks} · Время обработки: {elapsed.Elapsed.TotalSeconds:F1} с · Кнопка проверки доступна во время работы";
        };
        Opened += (_, _) => timer.Start();
        Closed += (_, _) => timer.Stop();
        Closing += OnClosing;
    }

    private async void OnBrowseClick(object? sender, RoutedEventArgs e)
    {
        try
        {
            var selected = await StorageProvider.OpenFolderPickerAsync(new FolderPickerOpenOptions
            { Title = "Папка с CSV", AllowMultiple = false });
            if (selected.Count > 0 && !running) FolderBox.Text = selected[0].TryGetLocalPath();
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or NotSupportedException)
        { ShowStatus("Не удалось открыть выбор папки. Введите путь вручную.", true); }
    }

    private async void OnStartClick(object? sender, RoutedEventArgs e)
    {
        if (running) return;
        ActiveRun = RunBatchAsync();
        await ActiveRun;
    }

    private async Task RunBatchAsync()
    {
        string folder = (FolderBox.Text ?? "").Trim();
        if (string.IsNullOrWhiteSpace(folder)) { ShowStatus("Укажите папку с CSV-файлами.", true); return; }
        running = true;
        int currentRun = ++runId;
        cancellation = new CancellationTokenSource();
        var token = cancellation.Token;
        SetControls();
        elapsed.Restart();
        files.Clear(); lookup.Clear();
        DetailsText.Text = "Выберите файл для подробностей";
        OutputText.Text = "Результаты будут сохранены в " + Path.Combine(folder, "_csv_results");
        OverallProgress.Value = 0;
        OverallProgress.IsIndeterminate = true;
        CounterText.Text = "Поиск CSV…";
        var processor = new BatchProcessor();
        try
        {
            ShowStatus("Поиск CSV-файлов…");
            var paths = await processor.FindCsvFilesAsync(folder, RecursiveCheck.IsChecked == true, token);
            foreach (string path in paths) { var item = new FileItem(path); files.Add(item); lookup.Add(path, item); }
            OverallProgress.IsIndeterminate = false;
            if (paths.Length == 0) { ShowStatus("В выбранной папке CSV-файлы не найдены."); CounterText.Text = "Файлов: 0"; return; }
            char delimiter = DelimiterBox.SelectedIndex switch { 1 => ';', 2 => '\t', _ => ',' };
            int parallel = ConcurrencyBox.SelectedIndex switch { 0 => 1, 1 => 2, 2 => 4, _ => 8 };
            var options = new BatchOptions(delimiter, parallel, SlowCheck.IsChecked == true ? 30 : 0);
            // Progress создаётся на UI-потоке; фоновые задачи не обращаются к контролам.
            var progress = new Progress<FileUpdate>(update =>
            {
                if (!running || currentRun != runId || !lookup.TryGetValue(update.Path, out var item)) return;
                item.Update(update);
                UpdateCounter();
            });
            ShowStatus($"Обработка: {paths.Length} файлов, до {parallel} задач одновременно.");
            var result = await processor.ProcessAsync(paths, Path.Combine(folder, "_csv_results"), options, progress, token);
            // Итоговый снимок исключает влияние запоздавших сообщений Progress.
            runId++;
            foreach (var outcome in result.Files) lookup[outcome.Path].Finish(outcome);
            UpdateCounter();
            OutputText.Text = "Результаты: " + result.OutputDirectory;
            ShowStatus(result.Canceled
                ? $"Обработка отменена. Готово: {result.Completed}; ошибок: {result.Errors}. Готовые JSON сохранены."
                : $"Обработка завершена. Готово: {result.Completed}; ошибок: {result.Errors}.", result.Errors > 0);
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested)
        { ShowStatus("Поиск отменён. Обработка не начата."); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException)
        {
            // При ошибке итогового отчёта успешно созданные JSON тоже остаются на диске.
            ShowStatus("Ошибка: " + ex.Message + " Уже созданные результаты остаются на диске.", true);
        }
        finally
        {
            elapsed.Stop();
            OverallProgress.IsIndeterminate = false;
            running = false;
            cancellation.Dispose(); cancellation = null;
            SetControls();
            if (closeRequested) Close();
        }
    }

    private void OnCancelClick(object? sender, RoutedEventArgs e)
    {
        if (!running || cancellation is null) return;
        cancellation.Cancel();
        CancelButton.IsEnabled = false;
        ShowStatus("Отмена запрошена. Дожидаемся остановки задач и сохранения сводки…");
    }

    private void SetControls()
    {
        StartButton.IsEnabled = BrowseButton.IsEnabled = FolderBox.IsEnabled = !running;
        DelimiterBox.IsEnabled = ConcurrencyBox.IsEnabled = RecursiveCheck.IsEnabled = SlowCheck.IsEnabled = !running;
        CancelButton.IsEnabled = running;
    }

    private void UpdateCounter()
    {
        int done = files.Count(x => x.State is "Готово" or "Ошибка");
        int active = files.Count(x => x.State == "Обработка");
        int stopped = files.Count(x => x.State is "Отменён" or "Пропущен");
        CounterText.Text = $"Готово/ошибки: {done}/{files.Count} · В работе: {active} · Остановлено: {stopped}";
        OverallProgress.Value = files.Count == 0 ? 0 : 100d * done / files.Count;
    }

    private void OnProbeClick(object? sender, RoutedEventArgs e) => ProbeText.Text = $"Нажатий: {++probeCount}";

    private void OnFileSelected(object? sender, SelectionChangedEventArgs e)
    {
        if (FilesList.SelectedItem is not FileItem item) return;
        DetailsText.Text = item.Path + "\n" + item.Detail + (item.Outcome?.ResultFile is { } path ? "\nJSON: " + path : "");
    }

    private void OnClosing(object? sender, CancelEventArgs e)
    {
        if (!running) return;
        e.Cancel = true;
        closeRequested = true;
        OnCancelClick(sender, new RoutedEventArgs());
    }

    private void ShowStatus(string text, bool error = false)
    { StatusText.Text = text; StatusText.Foreground = error ? Brushes.Firebrick : Brushes.SeaGreen; }
}
