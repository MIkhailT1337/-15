using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace CsvBatch.Core;

public sealed class BatchProcessor
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    // У Directory нет async API: перечисление каталога переносим с UI в пул потоков.
    public async Task<string[]> FindCsvFilesAsync(string folder, bool recursive, CancellationToken token) => await Task.Run(() =>
    {
        token.ThrowIfCancellationRequested();
        if (!Directory.Exists(folder)) throw new DirectoryNotFoundException("Указанная папка не найдена.");
        var files = new List<string>();
        var pending = new Stack<string>(); pending.Push(Path.GetFullPath(folder));
        while (pending.TryPop(out string? directory))
        {
            token.ThrowIfCancellationRequested();
            foreach (string file in Directory.EnumerateFiles(directory))
            {
                token.ThrowIfCancellationRequested();
                if (Path.GetExtension(file).Equals(".csv", StringComparison.OrdinalIgnoreCase)) files.Add(file);
            }
            if (!recursive) continue;
            foreach (string child in Directory.EnumerateDirectories(directory))
            {
                token.ThrowIfCancellationRequested();
                // Не заходим в символьные ссылки и папку результатов: исключаем циклы обхода.
                if ((File.GetAttributes(child) & FileAttributes.ReparsePoint) == 0
                    && Path.GetFileName(child) != "_csv_results") pending.Push(child);
            }
        }
        files.Sort(StringComparer.Ordinal);
        return files.ToArray();
    }, token).ConfigureAwait(false);

    public async Task<BatchResult> ProcessAsync(string[] files, string outputRoot, BatchOptions options,
        IProgress<FileUpdate>? progress, CancellationToken token)
    {
        if (options.Delimiter is not (',' or ';' or '\t')) throw new ArgumentException("Выберите разделитель CSV.");
        if (options.MaxConcurrency is < 1 or > 8) throw new ArgumentException("Количество задач должно быть от 1 до 8.");
        if (options.DelayPerRecordMs is < 0 or > 1000) throw new ArgumentException("Некорректная задержка.");
        if (files.Distinct(StringComparer.Ordinal).Count() != files.Length) throw new ArgumentException("Список содержит повторные пути.");
        token.ThrowIfCancellationRequested();
        string output = Path.Combine(Path.GetFullPath(outputRoot), DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..8]);
        Directory.CreateDirectory(output);
        var outcomes = new ConcurrentDictionary<string, FileOutcome>(StringComparer.Ordinal);
        foreach (string file in files) outcomes[file] = new(file, "Ожидание");
        bool canceled = false;
        try
        {
            await Parallel.ForEachAsync(files, new ParallelOptions
            {
                MaxDegreeOfParallelism = options.MaxConcurrency, CancellationToken = token
            }, async (file, ct) =>
            {
                outcomes[file] = new(file, "Обработка");
                progress?.Report(new(file, "Обработка"));
                try
                {
                    var stats = await new CsvAnalyzer().AnalyzeAsync(file, options,
                        count => progress?.Report(new(file, "Обработка", count)), ct);
                    ct.ThrowIfCancellationRequested();
                    string hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(file)))[..16];
                    string resultFile = Path.Combine(output, Path.GetFileName(file) + "-" + hash + ".json");
                    await WriteAtomicallyAsync(resultFile, new { Source = file, Statistics = stats }, ct);
                    // После атомарной публикации результат считается готовым, даже если отмена пришла следом.
                    outcomes[file] = new(file, "Готово", stats, resultFile);
                    progress?.Report(new(file, "Готово", stats.Records, $"Сумма: {stats.Sum}"));
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    outcomes[file] = new(file, "Отменён");
                    progress?.Report(new(file, "Отменён"));
                    throw;
                }
                catch (Exception ex) when (ex is FormatException or IOException or UnauthorizedAccessException
                    or DecoderFallbackException or NotSupportedException)
                {
                    outcomes[file] = new(file, "Ошибка", Error: ex.Message);
                    progress?.Report(new(file, "Ошибка", Detail: $"Ошибка в файле {Path.GetFileName(file)}: {ex.Message}"));
                }
            }).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { canceled = true; }
        foreach (string file in files)
            if (outcomes[file].State == "Ожидание") outcomes[file] = new(file, "Пропущен");
        var result = new BatchResult(canceled, output, files.Select(f => outcomes[f]).ToArray());
        // Сводку пишем и после отмены, чтобы сохранить сведения о завершённых файлах.
        await WriteAtomicallyAsync(Path.Combine(output, "batch-summary.json"), result, CancellationToken.None).ConfigureAwait(false);
        return result;
    }

    private static async Task WriteAtomicallyAsync<T>(string path, T value, CancellationToken token)
    {
        string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            await using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                16384, FileOptions.Asynchronous))
                await JsonSerializer.SerializeAsync(stream, value, JsonOptions, token).ConfigureAwait(false);
            token.ThrowIfCancellationRequested();
            File.Move(temp, path);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
}
