using System.Globalization;
using System.Text;

namespace CsvBatch.Core;

// Потоковый разбор CSV: заголовок, экранирование кавычек, многострочные поля.
// В памяти хранится только текущая логическая запись, а не весь файл.
public sealed class CsvAnalyzer
{
    public async Task<CsvStatistics> AnalyzeAsync(string path, BatchOptions options,
        Action<long>? onProgress, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read,
            65536, FileOptions.Asynchronous | FileOptions.SequentialScan);
        using var reader = new StreamReader(stream, new UTF8Encoding(true, true),
            detectEncodingFromByteOrderMarks: false, bufferSize: 65536);
        long physicalLine = 0, records = 0, numeric = 0;
        decimal sum = 0;
        string[]? header = null;
        var fields = new List<string>();
        var field = new StringBuilder();
        // 0 = начало поля, 1 = без кавычек, 2 = внутри кавычек, 3 = после кавычки.
        int state = 0;
        bool continued = false;
        while (await reader.ReadLineAsync(token).ConfigureAwait(false) is string line)
        {
            token.ThrowIfCancellationRequested();
            physicalLine++;
            if (!continued && line.Length == 0) continue; // Пропускаем пустые физические строки.
            if (continued) field.Append('\n');
            for (int i = 0; i < line.Length; i++)
            {
                if ((i & 1023) == 0) token.ThrowIfCancellationRequested();
                char ch = line[i];
                if (state == 2)
                {
                    if (ch == '"') state = 3; else field.Append(ch);
                }
                else if (state == 3)
                {
                    if (ch == '"') { field.Append('"'); state = 2; }
                    else if (ch == options.Delimiter) { fields.Add(field.ToString()); field.Clear(); state = 0; }
                    else throw Bad(physicalLine, "после закрывающей кавычки ожидается разделитель");
                }
                else if (ch == options.Delimiter)
                {
                    fields.Add(field.ToString()); field.Clear(); state = 0;
                }
                else if (ch == '"')
                {
                    if (state != 0) throw Bad(physicalLine, "кавычка внутри неэкранированного поля");
                    state = 2;
                }
                else { field.Append(ch); state = 1; }
            }
            // Учебный предел защищает от бесконечно незакрытого поля.
            if (field.Length + fields.Sum(x => x.Length) > 1_000_000)
                throw Bad(physicalLine, "логическая запись длиннее 1 000 000 символов");
            continued = state == 2;
            if (continued) continue;
            fields.Add(field.ToString()); field.Clear(); state = 0;
            if (header is null)
            {
                header = fields.Select(x => x.Trim()).ToArray();
                if (header.Any(string.IsNullOrWhiteSpace) || header.Distinct(StringComparer.OrdinalIgnoreCase).Count() != header.Length)
                    throw Bad(physicalLine, "названия столбцов должны быть непустыми и уникальными");
            }
            else
            {
                if (fields.Count != header.Length)
                    throw Bad(physicalLine, $"ожидалось полей: {header.Length}, получено: {fields.Count}");
                foreach (string value in fields)
                {
                    token.ThrowIfCancellationRequested();
                    const NumberStyles style = NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint
                        | NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite;
                    if (!decimal.TryParse(value, style, CultureInfo.InvariantCulture, out decimal number)) continue;
                    try { sum = checked(sum + number); } catch (OverflowException) { throw Bad(physicalLine, "переполнение суммы чисел"); }
                    numeric++;
                }
                records++;
                if (records == 1 || records % 100 == 0) onProgress?.Invoke(records);
                if (options.DelayPerRecordMs > 0)
                    await Task.Delay(options.DelayPerRecordMs, token).ConfigureAwait(false);
            }
            fields.Clear();
        }
        token.ThrowIfCancellationRequested();
        if (continued) throw Bad(physicalLine, "не закрыта кавычка до конца файла");
        if (header is null) throw Bad(physicalLine, "файл пуст или не содержит заголовка");
        return new(records, header.Length, numeric, sum);
    }

    private static FormatException Bad(long line, string detail) => new($"Строка {line}: {detail}.");
}
