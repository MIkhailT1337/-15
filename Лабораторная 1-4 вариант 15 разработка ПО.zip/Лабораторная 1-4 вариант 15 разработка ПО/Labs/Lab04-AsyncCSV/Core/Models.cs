namespace CsvBatch.Core;

public sealed record BatchOptions(char Delimiter, int MaxConcurrency, int DelayPerRecordMs = 0);
public sealed record CsvStatistics(long Records, int Columns, long NumericCells, decimal Sum);
public sealed record FileUpdate(string Path, string State, long Records = 0, string Detail = "");
public sealed record FileOutcome(string Path, string State, CsvStatistics? Statistics = null,
    string? ResultFile = null, string? Error = null);
public sealed record BatchResult(bool Canceled, string OutputDirectory, FileOutcome[] Files)
{
    public int Completed => Files.Count(x => x.State == "Готово");
    public int Errors => Files.Count(x => x.State == "Ошибка");
}
