using System.ComponentModel;
using System.Runtime.CompilerServices;
using CsvBatch.Core;

namespace CsvBatch;

public sealed class FileItem(string path) : INotifyPropertyChanged
{
    public string Path { get; } = path;
    public string Name => System.IO.Path.GetFileName(Path);
    private string state = "Ожидание", detail = "";
    private long records;
    public string State => state;
    public string Detail => detail;
    public string RecordsText => $"Записей: {records}";
    public FileOutcome? Outcome { get; private set; }
    public event PropertyChangedEventHandler? PropertyChanged;
    public void Update(FileUpdate update)
    {
        state = update.State;
        records = update.Records;
        if (!string.IsNullOrWhiteSpace(update.Detail)) detail = update.Detail;
        Changed(nameof(State)); Changed(nameof(RecordsText)); Changed(nameof(Detail));
    }
    public void Finish(FileOutcome outcome)
    {
        Outcome = outcome;
        string detail = outcome.Error is not null ? "Ошибка в файле: " + outcome.Error
            : outcome.Statistics is { } stats ? $"Столбцов: {stats.Columns} · Числовых ячеек: {stats.NumericCells} · Сумма: {stats.Sum}"
            : "Готовый результат не создан";
        Update(new(Path, outcome.State, outcome.Statistics?.Records ?? 0, detail));
    }
    private void Changed([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new(name));
}
