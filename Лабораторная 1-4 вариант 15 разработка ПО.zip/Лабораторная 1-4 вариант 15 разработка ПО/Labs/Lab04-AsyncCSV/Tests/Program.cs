using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Interactivity;
using Avalonia.Threading;
using CsvBatch;
using CsvBatch.Core;

void Check(bool ok, string name)
{
    if (!ok) throw new Exception("FAIL: " + name);
    Console.WriteLine("PASS: " + name);
}
var root = Path.Combine(Path.GetTempPath(), "CsvBatchChecks", Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
string Write(string name, string content)
{
    string path = Path.Combine(root, name); File.WriteAllText(path, content); return path;
}
var analyzer = new CsvAnalyzer();
var processor = new BatchProcessor();
var normal = new BatchOptions(',', 2);
string csv = Write("01-normal.csv", "name,value\n\"a,b\",2.5\n\"a\"\"b\",-1\n\"multi\nline\",3\n");
var stats = await analyzer.AnalyzeAsync(csv, normal, null, default);
Check(stats == new CsvStatistics(3, 2, 3, 4.5m), "quoted delimiter, escaped quotes, multiline field and numeric sum");
string semi = Write("02-semi.CSV", "a;b\n1;2\n");
Check((await analyzer.AnalyzeAsync(semi, normal with { Delimiter = ';' }, null, default)).Sum == 3, "semicolon delimiter");
string tab = Write("03-tab.csv", "a\tb\n1\t2\n");
Check((await analyzer.AnalyzeAsync(tab, normal with { Delimiter = '\t' }, null, default)).Columns == 2, "tab delimiter");
foreach (var (name, content) in new[] { ("columns", "a,b\n1,2,3\n"), ("quotes", "a,b\n\"open,2\n"), ("header", "a,a\n1,2\n"), ("empty", "") })
{
    bool failed = false;
    try { await analyzer.AnalyzeAsync(Write(name + ".csv", content), normal, null, default); }
    catch (FormatException) { failed = true; }
    Check(failed, "format error: " + name);
}
Directory.CreateDirectory(Path.Combine(root, "nested"));
File.WriteAllText(Path.Combine(root, "nested", "extra.csv"), "x\n1\n");
Check((await processor.FindCsvFilesAsync(root, true, default)).Length == 8
    && (await processor.FindCsvFilesAsync(root, false, default)).Length == 7, "search includes uppercase extension and optional subfolders");
using (var canceled = new CancellationTokenSource())
{
    canceled.Cancel(); bool stopped = false;
    try { await processor.FindCsvFilesAsync(root, true, canceled.Token); } catch (OperationCanceledException) { stopped = true; }
    Check(stopped, "cancellation during file discovery");
}
bool missing = false;
try { await processor.FindCsvFilesAsync(Path.Combine(root, "missing"), false, default); }
catch (DirectoryNotFoundException) { missing = true; }
Check(missing, "missing folder handled");
string bad = Path.Combine(root, "columns.csv");
var batch = await processor.ProcessAsync([csv, bad], Path.Combine(root, "results"), normal, null, default);
Check(batch.Completed == 1 && batch.Errors == 1 && File.Exists(batch.Files[0].ResultFile), "format error isolated while good result saved");
using (var summary = JsonDocument.Parse(File.ReadAllText(Path.Combine(batch.OutputDirectory, "batch-summary.json"))))
    Check(summary.RootElement.GetProperty("Files").GetArrayLength() == 2, "batch summary persisted");

string small = Write("00-small.csv", "name,value\nОдин,1\n");
string longFile = Write("10-long.csv", "name,value\n" + string.Concat(Enumerable.Range(1, 100).Select(i => $"Строка,{i}\n")));
string queued = Write("20-queued.csv", "name,value\nОчередь,3\n");
using (var cancel = new CancellationTokenSource())
{
    int active = 0, maxActive = 0;
    var progress = new CallbackProgress(update =>
    {
        if (update.State == "Обработка" && update.Records == 0)
        {
            int current = Interlocked.Increment(ref active);
            int previous;
            do { previous = maxActive; if (previous >= current) break; }
            while (Interlocked.CompareExchange(ref maxActive, current, previous) != previous);
        }
        if (update.State is "Готово" or "Ошибка" or "Отменён") Interlocked.Decrement(ref active);
        if (update.Path == small && update.State == "Готово") cancel.Cancel();
    });
    var canceled = await processor.ProcessAsync([small, longFile, queued], Path.Combine(root, "cancel-results"), normal with { DelayPerRecordMs = 25 }, progress, cancel.Token);
    Check(maxActive == 2, "two independent files run concurrently within configured limit");
    Check(canceled.Canceled && canceled.Completed == 1 && canceled.Files.Any(x => x.State == "Отменён") && canceled.Files.Any(x => x.State == "Пропущен"), "cancel stops active work and skips pending files");
    Check(File.Exists(canceled.Files.Single(x => x.State == "Готово").ResultFile)
        && !Directory.EnumerateFiles(canceled.OutputDirectory).Any(p => p.EndsWith(".tmp")), "completed result preserved and incomplete temporary files removed");
}

// UI tests use actual files, task cancellation and a dispatcher timer, without injected outcomes.
AppBuilder.Configure<App>().UseSkia().WithInterFont()
    .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false }).SetupWithoutStarting();
var window = new MainWindow();
T Find<T>(string name) where T : Control => window.FindControl<T>(name)!;
void PumpUntil(Func<bool> done)
{
    var deadline = DateTime.UtcNow.AddSeconds(20);
    while (!done())
    {
        Dispatcher.UIThread.RunJobs();
        if (DateTime.UtcNow > deadline) throw new TimeoutException("UI timed out");
        Thread.Sleep(10);
    }
    Dispatcher.UIThread.RunJobs();
}
void Click(string name) => Find<Button>(name).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
void Capture(string name)
{
    if (!args.Contains("--capture")) return;
    Directory.CreateDirectory("Images");
    Dispatcher.UIThread.RunJobs(); AvaloniaHeadlessPlatform.ForceRenderTimerTick();
    using var frame = window.CaptureRenderedFrame(); frame!.Save(Path.Combine("Images", name + ".png"));
}
var uiInput = Path.Combine(root, "ui-input"); Directory.CreateDirectory(uiInput);
File.Copy(small, Path.Combine(uiInput, "01-small.csv"));
File.Copy(longFile, Path.Combine(uiInput, "02-long.csv"));
File.Copy(bad, Path.Combine(uiInput, "03-bad.csv"));
window.Show();
Find<TextBox>("FolderBox").Text = uiInput;
Click("StartButton");
PumpUntil(() => Find<TextBlock>("StatusText").Text!.StartsWith("Обработка:") && Find<ListBox>("FilesList").Items.Cast<FileItem>().Any(x => x.State == "Готово"));
Click("ProbeButton");
bool dispatched = false;
Dispatcher.UIThread.Post(() => dispatched = true);
PumpUntil(() => dispatched);
Check(!window.ActiveRun!.IsCompleted && Find<TextBlock>("ProbeText").Text == "Нажатий: 1", "UI handles click and dispatcher callback while batch is still running");
Capture("01-running");
Click("CancelButton"); PumpUntil(() => window.ActiveRun!.IsCompleted);
Check(Find<TextBlock>("StatusText").Text!.Contains("отменена") && Find<Button>("StartButton").IsEnabled, "UI cancellation completes and enables restart");
Capture("02-canceled");
Find<CheckBox>("SlowCheck").IsChecked = false;
Click("StartButton"); PumpUntil(() => window.ActiveRun!.IsCompleted);
Check(Find<ListBox>("FilesList").Items.Cast<FileItem>().Count(x => x.State == "Готово") == 2
    && Find<ListBox>("FilesList").Items.Cast<FileItem>().Count(x => x.State == "Ошибка") == 1, "UI restart completes good files and displays file format error");
Capture("03-error-and-results");
window.Close();
Directory.Delete(root, true);
Console.WriteLine("All checks completed using real CSV files and filesystem output.");

sealed class CallbackProgress(Action<FileUpdate> action) : IProgress<FileUpdate>
{
    public void Report(FileUpdate value) => action(value);
}
