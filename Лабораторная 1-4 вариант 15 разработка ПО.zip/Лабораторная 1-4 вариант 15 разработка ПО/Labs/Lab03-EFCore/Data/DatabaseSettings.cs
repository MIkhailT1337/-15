using System.Text.Json;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace ContactManager.Data;

public sealed record DatabaseSettings(string Provider, string ConnectionString)
{
    public static string DataDirectory => Environment.GetEnvironmentVariable("CONTACT_MANAGER_DATA_DIR")
        ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ContactManagerLab3");

    public static DatabaseSettings Load()
    {
        string provider = "Sqlite";
        string? connection = null;
        string path = Path.Combine(AppContext.BaseDirectory, "database.local.json");
        if (File.Exists(path))
        {
            using var json = JsonDocument.Parse(File.ReadAllText(path));
            provider = json.RootElement.GetProperty("Provider").GetString() ?? "";
            connection = json.RootElement.GetProperty("ConnectionString").GetString();
        }
        provider = Environment.GetEnvironmentVariable("CONTACT_MANAGER_PROVIDER") ?? provider;
        connection = Environment.GetEnvironmentVariable("CONTACT_MANAGER_CONNECTION") ?? connection;
        if (provider.Equals("Sqlite", StringComparison.OrdinalIgnoreCase))
        {
            var builder = new SqliteConnectionStringBuilder(connection ?? $"Data Source={Path.Combine(DataDirectory, "contacts.db")}");
            if (string.IsNullOrWhiteSpace(builder.DataSource) || builder.DataSource == ":memory:" || builder.Mode == SqliteOpenMode.Memory)
                throw new InvalidOperationException("Для приложения укажите файловую SQLite базу, чтобы данные сохранялись после закрытия.");
            builder.DataSource = Path.GetFullPath(builder.DataSource);
            Directory.CreateDirectory(Path.GetDirectoryName(builder.DataSource)!);
            return new("Sqlite", builder.ConnectionString);
        }
        if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
        {
            if (string.IsNullOrWhiteSpace(connection)) throw new InvalidOperationException("Не настроено подключение SQL Server. Заполните database.local.json по образцу.");
            var builder = new SqlConnectionStringBuilder(connection) { ConnectTimeout = 5, PersistSecurityInfo = false };
            if (string.IsNullOrWhiteSpace(builder.DataSource) || string.IsNullOrWhiteSpace(builder.InitialCatalog))
                throw new InvalidOperationException("Укажите Server и Database для SQL Server.");
            return new("SqlServer", builder.ConnectionString);
        }
        throw new InvalidOperationException("Provider должен быть Sqlite или SqlServer.");
    }

    public AppDbContext CreateContext() => Provider == "Sqlite"
        ? new SqliteAppDbContext(new DbContextOptionsBuilder<SqliteAppDbContext>().UseSqlite(ConnectionString).Options)
        : new SqlServerAppDbContext(new DbContextOptionsBuilder<SqlServerAppDbContext>().UseSqlServer(ConnectionString,
            options => options.CommandTimeout(15)).Options);

    public string Description => Provider == "Sqlite"
        ? "SQLite · " + new SqliteConnectionStringBuilder(ConnectionString).DataSource
        : "SQL Server · " + new SqlConnectionStringBuilder(ConnectionString).InitialCatalog;
}

// Для создания миграций сервер не нужен: EF использует метаданные модели.
public sealed class SqliteDesignFactory : IDesignTimeDbContextFactory<SqliteAppDbContext>
{
    public SqliteAppDbContext CreateDbContext(string[] args) => new(new DbContextOptionsBuilder<SqliteAppDbContext>()
        .UseSqlite(Environment.GetEnvironmentVariable("CONTACT_MANAGER_CONNECTION") ?? "Data Source=contacts-design.db").Options);
}
public sealed class SqlServerDesignFactory : IDesignTimeDbContextFactory<SqlServerAppDbContext>
{
    public SqlServerAppDbContext CreateDbContext(string[] args) => new(new DbContextOptionsBuilder<SqlServerAppDbContext>()
        .UseSqlServer(Environment.GetEnvironmentVariable("CONTACT_MANAGER_CONNECTION")
            ?? "Server=localhost;Database=ContactManagerOrmDb;User ID=placeholder;Password=placeholder;Encrypt=True").Options);
}
