using Microsoft.EntityFrameworkCore;

namespace ContactManager.Data;

public sealed class ContactService(Func<AppDbContext> createContext)
{
    public async Task InitializeAsync()
    {
        await using var db = createContext();
        await db.Database.MigrateAsync();
    }

    public async Task<List<Contact>> GetAllAsync()
    {
        await using var db = createContext();
        // LINQ преобразуется EF Core в SQL; служебные вычисляемые свойства не запрашиваются.
        return await db.Contacts.AsNoTracking()
            .OrderBy(x => x.Importance == "Высокая" ? 0 : x.Importance == "Средняя" ? 1 : 2)
            .ThenBy(x => x.FullName).ThenBy(x => x.Id).ToListAsync();
    }

    public async Task AddAsync(Contact contact)
    {
        Validate(contact);
        await using var db = createContext();
        db.Contacts.Add(contact.Copy());
        await db.SaveChangesAsync();
    }

    public async Task UpdateAsync(Contact contact)
    {
        Validate(contact);
        await using var db = createContext();
        // Передаём версию, которую пользователь видел при выборе контакта.
        var entity = contact.Copy();
        db.Attach(entity);
        db.Entry(entity).State = EntityState.Modified;
        db.Entry(entity).Property(x => x.Revision).OriginalValue = contact.Revision;
        await db.SaveChangesAsync();
    }

    public async Task DeleteAsync(Contact contact)
    {
        await using var db = createContext();
        db.Contacts.Remove(contact.Copy());
        await db.SaveChangesAsync();
    }

    public static void Validate(Contact contact)
    {
        string[] parts = contact.FullName.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length < 2 || contact.FullName.Length > 100)
            throw new ArgumentException("Введите имя и фамилию длиной не более 100 символов.");
        if (contact.Category is not ("Друзья" or "Коллеги" or "Родственники"))
            throw new ArgumentException("Выберите категорию из списка.");
        if (contact.Importance is not ("Высокая" or "Средняя" or "Низкая"))
            throw new ArgumentException("Выберите важность из списка.");
    }
}
