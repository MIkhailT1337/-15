using Microsoft.EntityFrameworkCore;

namespace ContactManager.Data;

public abstract class AppDbContext(DbContextOptions options) : DbContext(options)
{
    public DbSet<Contact> Contacts => Set<Contact>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<Contact>();
        bool sqlServer = Database.IsSqlServer();
        string n = sqlServer ? "N" : "";
        entity.ToTable("Contacts", table =>
        {
            table.HasCheckConstraint("CK_Contacts_Name", sqlServer
                ? "LEN(LTRIM(RTRIM([FullName]))) BETWEEN 3 AND 100 AND CHARINDEX(N' ', LTRIM(RTRIM([FullName]))) > 1"
                : "length(trim(FullName)) BETWEEN 3 AND 100 AND instr(trim(FullName), ' ') > 1");
            table.HasCheckConstraint("CK_Contacts_Category", $"[Category] IN ({n}'Друзья', {n}'Коллеги', {n}'Родственники')");
            table.HasCheckConstraint("CK_Contacts_Importance", $"[Importance] IN ({n}'Высокая', {n}'Средняя', {n}'Низкая')");
        });
        entity.HasKey(x => x.Id);
        entity.Property(x => x.Id).ValueGeneratedNever();
        entity.Property(x => x.FullName).HasMaxLength(100).IsRequired();
        entity.Property(x => x.Category).HasMaxLength(30).IsRequired();
        entity.Property(x => x.Importance).HasMaxLength(10).IsRequired();
        entity.Property(x => x.Revision).IsConcurrencyToken().ValueGeneratedNever();
        entity.HasIndex(x => x.FullName);
    }

    private void SetRevisions()
    {
        foreach (var entry in ChangeTracker.Entries<Contact>())
            if (entry.State is EntityState.Added or EntityState.Modified)
                entry.Entity.Revision = Guid.NewGuid();
    }

    public override int SaveChanges(bool acceptAllChangesOnSuccess)
    {
        SetRevisions();
        return base.SaveChanges(acceptAllChangesOnSuccess);
    }
    public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default)
    {
        SetRevisions();
        return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
    }
}

// Отдельные типы контекста обеспечивают независимые миграции каждого провайдера.
public sealed class SqliteAppDbContext(DbContextOptions<SqliteAppDbContext> options) : AppDbContext(options);
public sealed class SqlServerAppDbContext(DbContextOptions<SqlServerAppDbContext> options) : AppDbContext(options);
