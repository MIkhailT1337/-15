﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261109144856_InitialCreate'
)
BEGIN
    CREATE TABLE [Contacts] (
        [Id] uniqueidentifier NOT NULL,
        [FullName] nvarchar(100) NOT NULL,
        [Category] nvarchar(30) NOT NULL,
        [Importance] nvarchar(10) NOT NULL,
        [HasCar] bit NOT NULL,
        [LikesSport] bit NOT NULL,
        [LikesIT] bit NOT NULL,
        [Revision] uniqueidentifier NOT NULL,
        CONSTRAINT [PK_Contacts] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_Contacts_Category] CHECK ([Category] IN (N'Друзья', N'Коллеги', N'Родственники')),
        CONSTRAINT [CK_Contacts_Importance] CHECK ([Importance] IN (N'Высокая', N'Средняя', N'Низкая')),
        CONSTRAINT [CK_Contacts_Name] CHECK (LEN(LTRIM(RTRIM([FullName]))) BETWEEN 3 AND 100 AND CHARINDEX(N' ', LTRIM(RTRIM([FullName]))) > 1)
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261109144856_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Contacts_FullName] ON [Contacts] ([FullName]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261109144856_InitialCreate'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20261109144856_InitialCreate', N'10.0.14');
END;

COMMIT;
GO
