using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text.Json;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media;
using ContactManager.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;

namespace ContactManager;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<Contact> contacts = new();
    private ContactService? service;
    private Contact? editing;
    private bool isReady, busy, loaded;

    public MainWindow()
    {
        InitializeComponent();
        ContactsList.ItemsSource = contacts;
        isReady = true;
        UpdatePreview();
        UpdateControls();
        Opened += async (_, _) => await RunAsync(InitializeAsync);
        Closing += OnClosing;
    }

    private async Task InitializeAsync()
    {
        loaded = false;
        var settings = DatabaseSettings.Load();
        ModeHint.Text = settings.Description;
        service = new ContactService(settings.CreateContext);
        ShowStatus("Подготовка базы по миграциям Code First…");
        // Microsoft.Data.Sqlite выполняет I/O синхронно даже в async API.
        // Вынесение всей операции в фон сохраняет отзывчивость окна.
        await Task.Run(service.InitializeAsync);
        await ReloadAsync();
        ShowStatus($"База готова. Загружено контактов: {contacts.Count}.");
    }

    private async Task RunAsync(Func<Task> operation)
    {
        if (busy) return;
        busy = true;
        UpdateControls();
        try { await operation(); }
        catch (Exception ex) when (IsExpected(ex)) { ShowStatus(ErrorMessage(ex), true); }
        finally { busy = false; UpdateControls(); }
    }

    private static bool IsExpected(Exception ex) => ex is DbUpdateException or SqlException or SqliteException
        or InvalidOperationException or ArgumentException or IOException or UnauthorizedAccessException
        or JsonException or KeyNotFoundException;

    private static string ErrorMessage(Exception ex) => ex switch
    {
        DbUpdateConcurrencyException => "Контакт уже изменён или удалён другим пользователем. Обновите список и повторите редактирование.",
        DbUpdateException => "Не удалось сохранить: нарушены ограничения базы или данные недоступны. Изменения формы оставлены для исправления.",
        SqlException => "SQL Server недоступен или недостаточно прав для миграций/запроса. Проверьте подключение и доступ к отдельной базе ЛР 3.",
        SqliteException => "Не удалось открыть SQLite базу. Проверьте путь, права записи и доступность файла.",
        JsonException or KeyNotFoundException => "Неверный database.local.json. Проверьте Provider и ConnectionString.",
        IOException or UnauthorizedAccessException => "Нет доступа к файлу настроек или папке базы данных.",
        _ => ex.Message
    };

    private async Task ReloadAsync()
    {
        loaded = false;
        var result = await Task.Run(service!.GetAllAsync);
        ResetForm();
        contacts.Clear();
        foreach (var contact in result) contacts.Add(contact);
        CountText.Text = $"Контактов: {contacts.Count}";
        EmptyText.IsVisible = contacts.Count == 0;
        loaded = true;
    }

    private string[] NameParts() => (FullNameBox.Text ?? "")
        .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);

    private bool ValidateName()
    {
        bool valid = NameParts().Length >= 2 && string.Join(" ", NameParts()).Length <= 100;
        FullNameBox.Classes.Set("error", !valid);
        NameError.IsVisible = !valid;
        return valid;
    }

    private Contact ReadContact() => new()
    {
        Id = editing?.Id ?? Guid.NewGuid(), FullName = string.Join(" ", NameParts()),
        Category = (CategoryBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Друзья",
        Importance = HighRadio.IsChecked == true ? "Высокая" : LowRadio.IsChecked == true ? "Низкая" : "Средняя",
        HasCar = CarCheck.IsChecked == true, LikesSport = SportCheck.IsChecked == true,
        LikesIT = ItCheck.IsChecked == true, Revision = editing?.Revision ?? Guid.NewGuid()
    };

    private async void OnSaveClick(object? sender, RoutedEventArgs e)
    {
        if (busy || !loaded) return;
        if (!ValidateName())
        {
            ShowStatus("Введите имя и фамилию. Данные не сохранены.", true);
            FullNameBox.Focus();
            return;
        }
        var contact = ReadContact();
        bool updating = editing is not null;
        await RunAsync(async () =>
        {
            if (updating) await Task.Run(() => service!.UpdateAsync(contact));
            else await Task.Run(() => service!.AddAsync(contact));
            await ReloadAfterWriteAsync();
            ShowStatus(updating ? "Изменения сохранены через EF Core." : "Контакт добавлен в базу через EF Core.");
        });
    }

    private async Task ReloadAfterWriteAsync()
    {
        loaded = false;
        try { await ReloadAsync(); }
        catch (Exception ex) when (IsExpected(ex))
        {
            throw new InvalidOperationException("Запись уже сохранена, но список не обновлён. Нажмите «Обновить из БД». Не повторяйте добавление.", ex);
        }
    }

    private async void OnDeleteClick(object? sender, RoutedEventArgs e)
    {
        if (busy || !loaded || ContactsList.SelectedItem is not Contact contact) return;
        await RunAsync(async () =>
        {
            await Task.Run(() => service!.DeleteAsync(contact));
            await ReloadAfterWriteAsync();
            ShowStatus("Контакт удалён из базы через EF Core.");
        });
    }

    private async void OnRefreshClick(object? sender, RoutedEventArgs e)
    {
        await RunAsync(InitializeAsync);
    }

    private void OnClearClick(object? sender, RoutedEventArgs e)
    {
        if (busy) return;
        ResetForm();
        UpdateControls();
        ShowStatus("Форма сброшена. Можно добавить новый контакт.");
    }

    private void ResetForm()
    {
        isReady = false;
        editing = null;
        ContactsList.SelectedItem = null;
        FullNameBox.Text = "";
        CategoryBox.SelectedIndex = 0;
        CarCheck.IsChecked = SportCheck.IsChecked = ItCheck.IsChecked = false;
        MediumRadio.IsChecked = true;
        FullNameBox.Classes.Set("error", false);
        NameError.IsVisible = false;
        EditorTitle.Text = "Новый контакт";
        SaveButton.Content = "Добавить контакт";
        DetailsText.Text = "Выберите контакт для просмотра и редактирования";
        isReady = true;
        UpdatePreview();
    }

    private void OnContactSelected(object? sender, SelectionChangedEventArgs e)
    {
        if (!isReady || busy || ContactsList.SelectedItem is not Contact contact) return;
        isReady = false;
        editing = contact;
        FullNameBox.Text = contact.FullName;
        CategoryBox.SelectedIndex = contact.Category switch { "Коллеги" => 1, "Родственники" => 2, _ => 0 };
        CarCheck.IsChecked = contact.HasCar;
        SportCheck.IsChecked = contact.LikesSport;
        ItCheck.IsChecked = contact.LikesIT;
        HighRadio.IsChecked = contact.Importance == "Высокая";
        MediumRadio.IsChecked = contact.Importance == "Средняя";
        LowRadio.IsChecked = contact.Importance == "Низкая";
        NameError.IsVisible = false;
        FullNameBox.Classes.Set("error", false);
        EditorTitle.Text = "Редактирование контакта";
        SaveButton.Content = "Сохранить изменения";
        DetailsText.Text = $"{contact.FullName}\n{contact.Summary}";
        isReady = true;
        UpdatePreview();
        UpdateControls();
    }

    private void UpdateControls()
    {
        EditorArea.IsEnabled = !busy && loaded;
        DeleteButton.IsEnabled = !busy && loaded && ContactsList.SelectedItem is Contact;
        RefreshButton.IsEnabled = !busy;
    }

    private void OnClosing(object? sender, CancelEventArgs e)
    {
        if (!busy) return;
        e.Cancel = true;
        ShowStatus("Дождитесь завершения операции с базой данных.", true);
    }

    private void OnNameChanged(object? sender, TextChangedEventArgs e)
    {
        if (isReady && NameError.IsVisible) ValidateName();
    }
    private void OnNameLostFocus(object? sender, RoutedEventArgs e)
    {
        if (isReady && !string.IsNullOrWhiteSpace(FullNameBox.Text)) ValidateName();
    }
    private void OnOptionsChanged(object? sender, RoutedEventArgs e)
    {
        if (isReady) UpdatePreview();
    }
    private void UpdatePreview() => PreviewText.Text = $"Будет сохранено: {ReadContact().Summary}";
    private void ShowStatus(string message, bool error = false)
    {
        StatusText.Text = message;
        StatusText.Foreground = error ? Brushes.Firebrick : Brushes.SeaGreen;
    }
}
