﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ContactManager.Migrations.Sqlite
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    FullName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                    Category = table.Column<string>(type: "TEXT", maxLength: 30, nullable: false),
                    Importance = table.Column<string>(type: "TEXT", maxLength: 10, nullable: false),
                    HasCar = table.Column<bool>(type: "INTEGER", nullable: false),
                    LikesSport = table.Column<bool>(type: "INTEGER", nullable: false),
                    LikesIT = table.Column<bool>(type: "INTEGER", nullable: false),
                    Revision = table.Column<Guid>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.Id);
                    table.CheckConstraint("CK_Contacts_Category", "[Category] IN ('Друзья', 'Коллеги', 'Родственники')");
                    table.CheckConstraint("CK_Contacts_Importance", "[Importance] IN ('Высокая', 'Средняя', 'Низкая')");
                    table.CheckConstraint("CK_Contacts_Name", "length(trim(FullName)) BETWEEN 3 AND 100 AND instr(trim(FullName), ' ') > 1");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_FullName",
                table: "Contacts",
                column: "FullName");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Contacts");
        }
    }
}
