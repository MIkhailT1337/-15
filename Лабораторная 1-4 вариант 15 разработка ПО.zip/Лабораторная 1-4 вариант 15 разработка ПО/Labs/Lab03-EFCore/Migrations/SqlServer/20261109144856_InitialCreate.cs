﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ContactManager.Migrations.SqlServer
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Category = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Importance = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    HasCar = table.Column<bool>(type: "bit", nullable: false),
                    LikesSport = table.Column<bool>(type: "bit", nullable: false),
                    LikesIT = table.Column<bool>(type: "bit", nullable: false),
                    Revision = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.Id);
                    table.CheckConstraint("CK_Contacts_Category", "[Category] IN (N'Друзья', N'Коллеги', N'Родственники')");
                    table.CheckConstraint("CK_Contacts_Importance", "[Importance] IN (N'Высокая', N'Средняя', N'Низкая')");
                    table.CheckConstraint("CK_Contacts_Name", "LEN(LTRIM(RTRIM([FullName]))) BETWEEN 3 AND 100 AND CHARINDEX(N' ', LTRIM(RTRIM([FullName]))) > 1");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_FullName",
                table: "Contacts",
                column: "FullName");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Contacts");
        }
    }
}
