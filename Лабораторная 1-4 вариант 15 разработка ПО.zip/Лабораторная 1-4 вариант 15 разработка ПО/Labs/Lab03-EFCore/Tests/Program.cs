using System.Reflection;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Interactivity;
using Avalonia.Threading;
using Avalonia.VisualTree;
using ContactManager;
using ContactManager.Data;
using Microsoft.EntityFrameworkCore;

void Check(bool ok, string name)
{
    if (!ok) throw new Exception("FAIL: " + name);
    Console.WriteLine("PASS: " + name);
}
string runDirectory = Path.Combine(Path.GetTempPath(), "ContactManagerLab3Checks", Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(runDirectory);
Environment.SetEnvironmentVariable("CONTACT_MANAGER_PROVIDER", "Sqlite");
Environment.SetEnvironmentVariable("CONTACT_MANAGER_CONNECTION", "Data Source=" + Path.Combine(runDirectory, "contacts.db"));
var settings = DatabaseSettings.Load();
var service = new ContactService(settings.CreateContext);
await service.InitializeAsync();
await using (var db = settings.CreateContext())
    Check((await db.Database.GetAppliedMigrationsAsync()).Count() == 1 && !db.Database.HasPendingModelChanges(), "Code First migration applied and snapshot matches model");
var first = new Contact { FullName = "Анна Смирнова", Category = "Коллеги", Importance = "Высокая", LikesSport = true, LikesIT = true };
await service.AddAsync(first);
var saved = (await service.GetAllAsync()).Single();
Check(saved.FullName == first.FullName && saved.LikesSport && saved.LikesIT, "ORM insert/read stores all fields");
Check((await new ContactService(settings.CreateContext).GetAllAsync()).Count == 1, "data persists across new contexts and services");
var stale = saved.Copy();
saved.FullName = "Анна Петрова";
await service.UpdateAsync(saved);
var updated = (await service.GetAllAsync()).Single();
Check(updated.FullName == "Анна Петрова" && updated.Revision != stale.Revision, "ORM update changes values and revision");
bool conflict = false;
try { await service.UpdateAsync(stale); } catch (DbUpdateConcurrencyException) { conflict = true; }
Check(conflict, "stale update rejected");
conflict = false;
try { await service.DeleteAsync(stale); } catch (DbUpdateConcurrencyException) { conflict = true; }
Check(conflict, "stale delete rejected");
bool invalid = false;
try { await service.AddAsync(new Contact { FullName = "Анна" }); } catch (ArgumentException) { invalid = true; }
Check(invalid && (await service.GetAllAsync()).Count == 1, "required name validation preserves database");
invalid = false;
try
{
    await using var db = settings.CreateContext();
    db.Contacts.Add(new Contact { FullName = "Тестовый Контакт", Category = "Неверная категория" });
    await db.SaveChangesAsync();
}
catch (DbUpdateException) { invalid = true; }
Check(invalid && (await service.GetAllAsync()).Count == 1, "real database CHECK constraint rejects invalid entity");
await service.DeleteAsync(updated);
Check((await service.GetAllAsync()).Count == 0, "ORM delete persists");

// Теперь проверяем те же операции через реальные элементы UI и настоящую SQLite базу.
AppBuilder.Configure<App>().UseSkia().WithInterFont()
    .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false }).SetupWithoutStarting();
var window = new MainWindow();
T Find<T>(string name) where T : Control => window.FindControl<T>(name)!;
void WaitForOperation()
{
    var deadline = DateTime.UtcNow.AddSeconds(30);
    while (true)
    {
        Dispatcher.UIThread.RunJobs();
        bool busy = (bool)typeof(MainWindow).GetField("busy", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(window)!;
        if (!busy) break;
        if (DateTime.UtcNow > deadline) throw new TimeoutException("UI operation timed out");
        Thread.Sleep(10);
    }
}
void Click(string text)
{
    window.GetVisualDescendants().OfType<Button>().Single(x => Equals(x.Content, text))
        .RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
    WaitForOperation();
}
void Capture(string name)
{
    if (!args.Contains("--capture")) return;
    Directory.CreateDirectory("Images");
    Dispatcher.UIThread.RunJobs();
    AvaloniaHeadlessPlatform.ForceRenderTimerTick();
    using var frame = window.CaptureRenderedFrame();
    frame!.Save(Path.Combine("Images", name + ".png"));
}
window.Show(); WaitForOperation();
Check(Find<Control>("EditorArea").IsEnabled, "UI initializes file database without server");
Click("Добавить контакт");
Check(Find<TextBlock>("NameError").IsVisible && Find<ListBox>("ContactsList").ItemCount == 0, "UI rejects empty name");
Capture("03-validation");
Find<TextBox>("FullNameBox").Text = "  Анна   Смирнова  ";
Find<ComboBox>("CategoryBox").SelectedIndex = 1;
Find<CheckBox>("SportCheck").IsChecked = true;
Find<CheckBox>("ItCheck").IsChecked = true;
Find<RadioButton>("HighRadio").IsChecked = true;
Click("Добавить контакт");
Check(Find<ListBox>("ContactsList").ItemCount == 1 && Find<TextBlock>("CountText").Text == "Контактов: 1", "UI adds through ORM and refreshes counter");
Find<ListBox>("ContactsList").SelectedIndex = 0;
Check(Find<TextBox>("FullNameBox").Text == "Анна Смирнова", "UI selects normalized name for editing");
Capture("01-contact");
Find<TextBox>("FullNameBox").Text = "Анна Петрова";
Click("Сохранить изменения");
Find<ListBox>("ContactsList").SelectedIndex = 0;
Check(Find<TextBox>("FullNameBox").Text == "Анна Петрова", "UI saves ORM update");
Capture("02-edited");
window.Close();
window = new MainWindow(); window.Show(); WaitForOperation();
Check(Find<ListBox>("ContactsList").ItemCount == 1, "contact survives window close and reopen");
Find<ListBox>("ContactsList").SelectedIndex = 0;
Click("Удалить выбранный");
Check(Find<ListBox>("ContactsList").ItemCount == 0 && !Find<Button>("DeleteButton").IsEnabled, "UI deletes and restores empty state");
window.Close();
Console.WriteLine("SQLite integration and UI checks completed. SQL Server not tested: no server provided.");
Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
Directory.Delete(runDirectory, recursive: true);
