using System.ComponentModel.DataAnnotations.Schema;

namespace ContactManager;

// Entity: один объект соответствует одной строке Contacts.
public sealed class Contact
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string FullName { get; set; } = "";
    public string Category { get; set; } = "Друзья";
    public string Importance { get; set; } = "Средняя";
    public bool HasCar { get; set; }
    public bool LikesSport { get; set; }
    public bool LikesIT { get; set; }
    public Guid Revision { get; set; } = Guid.NewGuid();

    [NotMapped]
    public string TagsText
    {
        get
        {
            var tags = new List<string>();
            if (HasCar) tags.Add("Автомобиль");
            if (LikesSport) tags.Add("Спорт");
            if (LikesIT) tags.Add("IT");
            return tags.Count == 0 ? "Без пометок" : string.Join(", ", tags);
        }
    }
    [NotMapped] public string Summary => $"{Category} · {Importance} важность · {TagsText}";
    public Contact Copy() => (Contact)MemberwiseClone();
}
