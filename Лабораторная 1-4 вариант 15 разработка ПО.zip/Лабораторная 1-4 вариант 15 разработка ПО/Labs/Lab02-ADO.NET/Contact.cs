namespace ContactManager;

public sealed record Contact(Guid Id, string FullName, string Category, string Importance,
    bool HasCar, bool LikesSport, bool LikesIT, byte[] Version)
{
    public string TagsText
    {
        get
        {
            var tags = new List<string>();
            if (HasCar) tags.Add("Автомобиль");
            if (LikesSport) tags.Add("Спорт");
            if (LikesIT) tags.Add("IT");
            return tags.Count == 0 ? "Без пометок" : string.Join(", ", tags);
        }
    }
    public string Summary => $"{Category} · {Importance} важность · {TagsText}";
}
