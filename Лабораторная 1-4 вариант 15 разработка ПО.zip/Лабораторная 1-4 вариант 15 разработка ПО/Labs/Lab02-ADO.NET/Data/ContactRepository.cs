using System.Data;
using Microsoft.Data.SqlClient;

namespace ContactManager.Data;

// Только этот класс знает о SQL Server. UI не содержит SQL-запросов.
public sealed class ContactRepository(string connectionString)
{
    private SqlConnection NewConnection() => new(connectionString);

    public static DataTable CreateTable()
    {
        var table = new DataTable("Contacts");
        table.Columns.Add("Id", typeof(Guid));
        table.Columns.Add("FullName", typeof(string));
        table.Columns.Add("Category", typeof(string));
        table.Columns.Add("Importance", typeof(string));
        table.Columns.Add("HasCar", typeof(bool));
        table.Columns.Add("LikesSport", typeof(bool));
        table.Columns.Add("LikesIT", typeof(bool));
        table.Columns.Add("Version", typeof(byte[]));
        table.PrimaryKey = [table.Columns["Id"]!];
        return table;
    }

    // Присоединённая модель: SqlDataReader читает при открытом соединении.
    public async Task<DataTable> LoadConnectedAsync()
    {
        var table = CreateTable();
        await using var connection = NewConnection();
        await connection.OpenAsync();
        using var command = Command("ContactList", connection);
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
            table.Rows.Add(reader.GetGuid(0), reader.GetString(1), reader.GetString(2),
                reader.GetString(3), reader.GetBoolean(4), reader.GetBoolean(5),
                reader.GetBoolean(6), (byte[])reader[7]);
        table.AcceptChanges();
        return table;
    }

    public async Task InsertAsync(Contact contact) => await ExecuteAsync("ContactInsert", contact);
    public async Task UpdateAsync(Contact contact) => await ExecuteAsync("ContactUpdate", contact);
    public async Task DeleteAsync(Contact contact) => await ExecuteAsync("ContactDelete", contact);

    private async Task ExecuteAsync(string procedure, Contact contact)
    {
        await using var connection = NewConnection();
        await connection.OpenAsync();
        using var command = Command(procedure, connection);
        command.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = contact.Id;
        if (procedure != "ContactDelete") AddValues(command, contact);
        if (procedure != "ContactInsert")
            command.Parameters.Add("@Version", SqlDbType.Binary, 8).Value = contact.Version;
        await command.ExecuteNonQueryAsync();
    }

    // Отсоединённая модель: после Fill соединение закрывается, UI редактирует DataTable.
    public DataTable LoadDisconnected()
    {
        using var connection = NewConnection();
        using var command = Command("ContactList", connection);
        using var adapter = new SqlDataAdapter(command);
        var table = CreateTable();
        adapter.Fill(table);
        return table;
    }

    // Все изменения одной локальной таблицы отправляются атомарно.
    // AcceptChanges вызывается только ПОСЛЕ успешного COMMIT.
    public void ApplyChanges(DataTable table)
    {
        using var connection = NewConnection();
        connection.Open();
        using var transaction = connection.BeginTransaction();
        using var insert = AdapterCommand("ContactInsert", connection, transaction);
        using var update = AdapterCommand("ContactUpdate", connection, transaction);
        using var delete = AdapterCommand("ContactDelete", connection, transaction);
        using var adapter = new SqlDataAdapter
        {
            InsertCommand = insert, UpdateCommand = update, DeleteCommand = delete,
            AcceptChangesDuringUpdate = false, ContinueUpdateOnError = false
        };
        try
        {
            adapter.Update(table);
            transaction.Commit();
            table.AcceptChanges();
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    private static SqlCommand AdapterCommand(string procedure, SqlConnection connection, SqlTransaction transaction)
    {
        var command = Command(procedure, connection);
        command.Transaction = transaction;
        void Map(string column, SqlDbType type, int size = 0, DataRowVersion version = DataRowVersion.Current)
        {
            var parameter = command.Parameters.Add("@" + column, type, size, column);
            parameter.SourceVersion = version;
        }
        Map("Id", SqlDbType.UniqueIdentifier, version: procedure == "ContactDelete" ? DataRowVersion.Original : DataRowVersion.Current);
        if (procedure != "ContactDelete")
        {
            Map("FullName", SqlDbType.NVarChar, 100); Map("Category", SqlDbType.NVarChar, 30);
            Map("Importance", SqlDbType.NVarChar, 10); Map("HasCar", SqlDbType.Bit);
            Map("LikesSport", SqlDbType.Bit); Map("LikesIT", SqlDbType.Bit);
        }
        if (procedure != "ContactInsert") Map("Version", SqlDbType.Binary, 8, DataRowVersion.Original);
        command.UpdatedRowSource = UpdateRowSource.None;
        return command;
    }

    private static SqlCommand Command(string name, SqlConnection connection) =>
        new("dbo." + name, connection) { CommandType = CommandType.StoredProcedure, CommandTimeout = 15 };

    private static void AddValues(SqlCommand command, Contact contact)
    {
        command.Parameters.Add("@FullName", SqlDbType.NVarChar, 100).Value = contact.FullName;
        command.Parameters.Add("@Category", SqlDbType.NVarChar, 30).Value = contact.Category;
        command.Parameters.Add("@Importance", SqlDbType.NVarChar, 10).Value = contact.Importance;
        command.Parameters.Add("@HasCar", SqlDbType.Bit).Value = contact.HasCar;
        command.Parameters.Add("@LikesSport", SqlDbType.Bit).Value = contact.LikesSport;
        command.Parameters.Add("@LikesIT", SqlDbType.Bit).Value = contact.LikesIT;
    }

    public static Contact FromRow(DataRow row) => new((Guid)row["Id"], (string)row["FullName"],
        (string)row["Category"], (string)row["Importance"], (bool)row["HasCar"],
        (bool)row["LikesSport"], (bool)row["LikesIT"], row["Version"] as byte[] ?? []);

    public static void WriteRow(DataRow row, Contact contact)
    {
        row["Id"] = contact.Id; row["FullName"] = contact.FullName;
        row["Category"] = contact.Category; row["Importance"] = contact.Importance;
        row["HasCar"] = contact.HasCar; row["LikesSport"] = contact.LikesSport; row["LikesIT"] = contact.LikesIT;
    }
}
