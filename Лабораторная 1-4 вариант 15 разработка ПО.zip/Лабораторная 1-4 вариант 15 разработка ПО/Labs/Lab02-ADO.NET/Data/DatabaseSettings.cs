using System.Text.Json;
using Microsoft.Data.SqlClient;

namespace ContactManager.Data;

public static class DatabaseSettings
{
    public static string LoadConnectionString()
    {
        string? value = Environment.GetEnvironmentVariable("CONTACT_MANAGER_SQL");
        if (string.IsNullOrWhiteSpace(value))
        {
            string path = Path.Combine(AppContext.BaseDirectory, "database.local.json");
            if (!File.Exists(path))
                throw new InvalidOperationException("Подключение не настроено. Создайте database.local.json по образцу database.example.json и нажмите «Обновить из БД».");
            using var document = JsonDocument.Parse(File.ReadAllText(path));
            value = document.RootElement.GetProperty("ConnectionString").GetString();
        }
        if (string.IsNullOrWhiteSpace(value))
            throw new InvalidOperationException("Строка подключения пуста. Проверьте database.local.json.");
        // Проверяем синтаксис до первого обращения к серверу; пароль нигде не выводится.
        var builder = new SqlConnectionStringBuilder(value);
        if (string.IsNullOrWhiteSpace(builder.DataSource) || string.IsNullOrWhiteSpace(builder.InitialCatalog))
            throw new InvalidOperationException("Укажите Server и Database в строке подключения.");
        builder.ConnectTimeout = 5;
        builder.PersistSecurityInfo = false;
        return builder.ConnectionString;
    }
}
