using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Text.Json;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media;
using ContactManager.Data;
using Microsoft.Data.SqlClient;

namespace ContactManager;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<Contact> contacts = new();
    private DataTable table = ContactRepository.CreateTable();
    private ContactRepository? repository;
    private Contact? editing;
    private bool isReady, busy, loaded, disconnected;
    private bool HasChanges => table.GetChanges() is not null;

    public MainWindow()
    {
        InitializeComponent();
        ContactsList.ItemsSource = contacts;
        isReady = true;
        UpdatePreview();
        UpdateControls();
        Opened += async (_, _) => await RunAsync(ReloadAsync);
        Closing += OnClosing;
    }

    private ContactRepository Repository => repository ??= new(DatabaseSettings.LoadConnectionString());

    private async Task RunAsync(Func<Task> operation)
    {
        if (busy) return;
        busy = true;
        UpdateControls();
        try { await operation(); }
        catch (Exception ex) when (ex is SqlException or InvalidOperationException or ArgumentException
            or IOException or JsonException or KeyNotFoundException or DBConcurrencyException)
        {
            ShowStatus(ErrorMessage(ex), true);
        }
        finally { busy = false; UpdateControls(); }
    }

    private static string ErrorMessage(Exception ex) => ex switch
    {
        SqlException sql when sql.Number == 50001 => "Запись изменена или удалена другим пользователем. Отмените локальные изменения и обновите список.",
        SqlException sql when sql.Number is 2601 or 2627 => "Контакт с таким идентификатором уже существует. Обновите данные перед повторной операцией.",
        SqlException sql when sql.Number == 18456 => "SQL Server отклонил вход. Проверьте пользователя и пароль в database.local.json.",
        SqlException sql when sql.Number == 229 => "Недостаточно прав. Администратор должен добавить пользователя в роль ContactManagerAppRole.",
        SqlException sql when sql.Number == 2812 => "Не найдены процедуры БД. Выполните Database/01-schema.sql на выбранном сервере.",
        SqlException => "Нет доступа к SQL Server или запрос завершился ошибкой. Проверьте адрес, порт, базу, сертификат и доступность сети. Локальные изменения сохранены в текущем окне.",
        DBConcurrencyException => "Конфликт изменений. Отмените локальные изменения и обновите список из БД.",
        JsonException or KeyNotFoundException or ArgumentException => "Некорректные настройки. Проверьте ConnectionString в database.local.json.",
        IOException => "Не удалось прочитать файл настроек подключения.",
        _ => ex.Message
    };

    private async Task ReloadAsync()
    {
        // Повторное чтение настроек позволяет настроить сервер без перезапуска.
        loaded = false;
        repository = new ContactRepository(DatabaseSettings.LoadConnectionString());
        ShowStatus("Загрузка из SQL Server…");
        var result = disconnected ? await Task.Run(Repository.LoadDisconnected)
            : await Repository.LoadConnectedAsync();
        table = result;
        loaded = true;
        ResetForm();
        RebuildList();
        ShowStatus($"Загружено контактов: {contacts.Count}. Данные прочитаны из SQL Server.");
    }

    private string[] NameParts() => (FullNameBox.Text ?? "")
        .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);

    private bool ValidateName()
    {
        bool valid = NameParts().Length >= 2 && string.Join(" ", NameParts()).Length <= 100;
        FullNameBox.Classes.Set("error", !valid);
        NameError.IsVisible = !valid;
        return valid;
    }

    private Contact ReadContact() => new(editing?.Id ?? Guid.NewGuid(), string.Join(" ", NameParts()),
        (CategoryBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Друзья",
        HighRadio.IsChecked == true ? "Высокая" : LowRadio.IsChecked == true ? "Низкая" : "Средняя",
        CarCheck.IsChecked == true, SportCheck.IsChecked == true, ItCheck.IsChecked == true,
        editing?.Version ?? []);

    private async void OnSaveClick(object? sender, RoutedEventArgs e)
    {
        if (busy || !loaded) return;
        if (!ValidateName())
        {
            ShowStatus("Введите имя и фамилию. Данные не сохранены.", true);
            FullNameBox.Focus();
            return;
        }
        Contact contact = ReadContact();
        bool updating = editing is not null;
        await RunAsync(async () =>
        {
            if (disconnected)
            {
                var row = updating ? table.Rows.Find(contact.Id)! : table.NewRow();
                ContactRepository.WriteRow(row, contact);
                if (!updating) table.Rows.Add(row);
                ResetForm();
                RebuildList();
                ShowStatus("Изменение выполнено локально. Нажмите «Отправить изменения» для сохранения в SQL Server.");
            }
            else
            {
                if (updating) await Repository.UpdateAsync(contact);
                else await Repository.InsertAsync(contact);
                await ReloadAfterWriteAsync();
                ShowStatus(updating ? "Изменения сохранены в SQL Server." : "Контакт добавлен в SQL Server.");
            }
        });
    }

    private async Task ReloadAfterWriteAsync()
    {
        // При сбое повторного чтения запретить новые записи со старой версией.
        loaded = false;
        try { await ReloadAsync(); }
        catch (Exception ex) when (ex is SqlException or IOException or InvalidOperationException or ArgumentException or JsonException or KeyNotFoundException)
        {
            throw new InvalidOperationException("Операция уже сохранена в БД, но список не обновлён. Нажмите «Обновить из БД». Не повторяйте добавление.", ex);
        }
    }

    private async void OnDeleteClick(object? sender, RoutedEventArgs e)
    {
        if (busy || !loaded || ContactsList.SelectedItem is not Contact contact) return;
        await RunAsync(async () =>
        {
            if (disconnected)
            {
                table.Rows.Find(contact.Id)!.Delete();
                ResetForm();
                RebuildList();
                ShowStatus("Удаление отмечено локально. Нажмите «Отправить изменения», чтобы удалить запись из БД.");
            }
            else
            {
                await Repository.DeleteAsync(contact);
                await ReloadAfterWriteAsync();
                ShowStatus("Контакт удалён из SQL Server.");
            }
        });
    }

    private async void OnApplyClick(object? sender, RoutedEventArgs e)
    {
        if (!disconnected || !loaded || !HasChanges) return;
        await RunAsync(async () =>
        {
            await Task.Run(() => Repository.ApplyChanges(table));
            await ReloadAfterWriteAsync();
            ShowStatus("Все локальные изменения сохранены в SQL Server одной транзакцией.");
        });
    }

    private void OnRevertClick(object? sender, RoutedEventArgs e)
    {
        if (busy) return;
        table.RejectChanges();
        ResetForm();
        RebuildList();
        UpdateControls();
        ShowStatus("Локальные изменения отменены. Для новых данных сервера нажмите «Обновить из БД».");
    }

    private async void OnRefreshClick(object? sender, RoutedEventArgs e)
    {
        if (HasChanges) return;
        await RunAsync(ReloadAsync);
    }

    private async void OnModeChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (!isReady || busy) return;
        bool next = DataModeBox.SelectedIndex == 1;
        if (next == disconnected) return;
        if (HasChanges)
        {
            isReady = false;
            DataModeBox.SelectedIndex = disconnected ? 1 : 0;
            isReady = true;
            return;
        }
        disconnected = next;
        await RunAsync(ReloadAsync);
    }

    private void OnClearClick(object? sender, RoutedEventArgs e)
    {
        if (busy) return;
        ResetForm();
        UpdateControls();
        ShowStatus("Форма сброшена. Можно добавить новый контакт.");
    }

    private void ResetForm()
    {
        isReady = false;
        editing = null;
        ContactsList.SelectedItem = null;
        FullNameBox.Text = "";
        CategoryBox.SelectedIndex = 0;
        CarCheck.IsChecked = SportCheck.IsChecked = ItCheck.IsChecked = false;
        MediumRadio.IsChecked = true;
        FullNameBox.Classes.Set("error", false);
        NameError.IsVisible = false;
        EditorTitle.Text = "Новый контакт";
        SaveButton.Content = "Добавить контакт";
        DetailsText.Text = "Выберите контакт для просмотра и редактирования";
        isReady = true;
        UpdatePreview();
    }

    private void OnContactSelected(object? sender, SelectionChangedEventArgs e)
    {
        if (!isReady || busy || ContactsList.SelectedItem is not Contact contact) return;
        isReady = false;
        editing = contact;
        FullNameBox.Text = contact.FullName;
        CategoryBox.SelectedIndex = contact.Category switch { "Коллеги" => 1, "Родственники" => 2, _ => 0 };
        CarCheck.IsChecked = contact.HasCar;
        SportCheck.IsChecked = contact.LikesSport;
        ItCheck.IsChecked = contact.LikesIT;
        HighRadio.IsChecked = contact.Importance == "Высокая";
        MediumRadio.IsChecked = contact.Importance == "Средняя";
        LowRadio.IsChecked = contact.Importance == "Низкая";
        NameError.IsVisible = false;
        FullNameBox.Classes.Set("error", false);
        EditorTitle.Text = "Редактирование контакта";
        SaveButton.Content = "Сохранить изменения";
        DetailsText.Text = $"{contact.FullName}\n{contact.Summary}";
        isReady = true;
        UpdatePreview();
        UpdateControls();
    }

    private void RebuildList()
    {
        isReady = false;
        contacts.Clear();
        foreach (DataRow row in table.Rows)
            if (row.RowState != DataRowState.Deleted) contacts.Add(ContactRepository.FromRow(row));
        isReady = true;
        CountText.Text = $"Контактов: {contacts.Count}";
        EmptyText.IsVisible = contacts.Count == 0;
    }

    private void UpdateControls()
    {
        bool pending = HasChanges;
        EditorArea.IsEnabled = !busy && loaded;
        DeleteButton.IsEnabled = !busy && loaded && ContactsList.SelectedItem is Contact;
        DataModeBox.IsEnabled = !busy && !pending;
        RefreshButton.IsEnabled = !busy && !pending;
        ApplyButton.IsVisible = RevertButton.IsVisible = disconnected;
        ApplyButton.IsEnabled = !busy && loaded && pending;
        RevertButton.IsEnabled = !busy && pending;
        int count = table.Rows.Cast<DataRow>().Count(r => r.RowState != DataRowState.Unchanged);
        ModeHint.Text = disconnected
            ? $"Локальная таблица DataTable. Изменений: {count}. Отправьте или отмените их перед обновлением и выходом."
            : "Прямой доступ: каждое действие сразу выполняется в SQL Server. Выбор контакта открывает редактирование.";
    }

    private void OnClosing(object? sender, CancelEventArgs e)
    {
        if (!busy && !HasChanges) return;
        e.Cancel = true;
        ShowStatus(busy ? "Дождитесь завершения операции с БД."
            : "Есть локальные изменения: отправьте или отмените их перед выходом.", true);
    }

    private void OnNameChanged(object? sender, TextChangedEventArgs e)
    {
        if (isReady && NameError.IsVisible) ValidateName();
    }
    private void OnNameLostFocus(object? sender, RoutedEventArgs e)
    {
        if (isReady && !string.IsNullOrWhiteSpace(FullNameBox.Text)) ValidateName();
    }
    private void OnOptionsChanged(object? sender, RoutedEventArgs e)
    {
        if (isReady) UpdatePreview();
    }
    private void UpdatePreview() => PreviewText.Text = $"Будет сохранено: {ReadContact().Summary}";
    private void ShowStatus(string message, bool error = false)
    {
        StatusText.Text = message;
        StatusText.Foreground = error ? Brushes.Firebrick : Brushes.SeaGreen;
    }
}
