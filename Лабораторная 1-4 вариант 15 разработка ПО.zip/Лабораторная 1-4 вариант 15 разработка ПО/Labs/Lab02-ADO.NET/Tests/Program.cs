using System.Data;
using System.Reflection;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Interactivity;
using Avalonia.Threading;
using Avalonia.VisualTree;
using ContactManager;
using ContactManager.Data;
using Microsoft.Data.SqlClient;
using Microsoft.SqlServer.TransactSql.ScriptDom;

void Check(bool ok, string name)
{
    if (!ok) throw new Exception("FAIL: " + name);
    Console.WriteLine("PASS: " + name);
}

if (args.Contains("--integration"))
{
    // Требуется заранее подготовленная БД. Работаем только со своими тестовыми GUID.
    var repository = new ContactRepository(DatabaseSettings.LoadConnectionString());
    var ids = new List<Guid>();
    Contact Sample(string name) => new(Guid.NewGuid(), name, "Коллеги", "Высокая", true, false, true, []);
    try
    {
        var original = Sample("Тестовый Контакт"); ids.Add(original.Id);
        await repository.InsertAsync(original);
        var data = await repository.LoadConnectedAsync();
        var saved = ContactRepository.FromRow(data.Rows.Find(original.Id)!);
        Check(saved.FullName == original.FullName && saved.Version.Length == 8, "connected insert/read and rowversion");
        await repository.UpdateAsync(saved with { FullName = "Изменённый Контакт" });
        bool conflict = false;
        try { await repository.UpdateAsync(saved); }
        catch (SqlException ex) when (ex.Number == 50001) { conflict = true; }
        Check(conflict, "stale update rejected");

        var local = repository.LoadDisconnected();
        var row = local.Rows.Find(original.Id)!;
        row["Category"] = "Друзья";
        var additional = Sample("Второй Контакт"); ids.Add(additional.Id);
        var added = local.NewRow(); ContactRepository.WriteRow(added, additional); local.Rows.Add(added);
        repository.ApplyChanges(local);
        var fresh = await repository.LoadConnectedAsync();
        Check((string)fresh.Rows.Find(original.Id)!["Category"] == "Друзья" && fresh.Rows.Find(additional.Id) != null,
            "DataAdapter sends update and insert");

        local = repository.LoadDisconnected();
        local.Rows.Find(additional.Id)!.Delete();
        repository.ApplyChanges(local);
        Check((await repository.LoadConnectedAsync()).Rows.Find(additional.Id) is null, "DataAdapter sends delete");

        local = repository.LoadDisconnected();
        var before = (string)local.Rows.Find(original.Id)!["FullName"];
        local.Rows.Find(original.Id)!["FullName"] = "Транзакционный Контакт";
        var invalid = Sample("Неверный Контакт"); ids.Add(invalid.Id);
        var invalidRow = local.NewRow();
        ContactRepository.WriteRow(invalidRow, invalid with { Category = "Неверная категория" });
        local.Rows.Add(invalidRow);
        bool rolledBack = false;
        try { repository.ApplyChanges(local); } catch (SqlException) { rolledBack = true; }
        fresh = await repository.LoadConnectedAsync();
        Check(rolledBack && (string)fresh.Rows.Find(original.Id)!["FullName"] == before
            && fresh.Rows.Find(invalid.Id) is null && local.GetChanges() is not null,
            "transaction rollback preserves database and pending changes");

        await using var connection = new SqlConnection(DatabaseSettings.LoadConnectionString());
        await connection.OpenAsync();
        using var forbidden = new SqlCommand("SELECT * FROM dbo.Contacts", connection);
        bool denied = false;
        try { await forbidden.ExecuteNonQueryAsync(); } catch (SqlException ex) when (ex.Number == 229) { denied = true; }
        Check(denied, "app role cannot access table directly (run with contact_app, not admin)");
    }
    finally
    {
        var data = await repository.LoadConnectedAsync();
        foreach (Guid id in ids)
            if (data.Rows.Find(id) is DataRow row) await repository.DeleteAsync(ContactRepository.FromRow(row));
    }
    return;
}

// Microsoft ScriptDom проверяет синтаксис T-SQL, но не заменяет выполнение на сервере.
var source = new DirectoryInfo(AppContext.BaseDirectory);
while (source is not null && !File.Exists(Path.Combine(source.FullName, "ContactManager.csproj"))) source = source.Parent;
foreach (string script in new[] { "01-schema.sql", "02-user.sql" })
{
    using var input = File.OpenText(Path.Combine(source!.FullName, "Database", script));
    new TSql160Parser(true).Parse(input, out var errors);
    foreach (var error in errors) Console.WriteLine($"SQL {script}:{error.Line}: {error.Message}");
    Check(errors.Count == 0, "T-SQL syntax: " + script);
}

// Проверяем, что SqlClient реально загружается на macOS и выдаёт SQL-ошибку для недоступного порта.
bool connectionFailed = false;
try
{
    using var inaccessible = new SqlConnection("Server=tcp:127.0.0.1,1;Database=ContactManagerDb;User ID=test;Password=test;Encrypt=True;TrustServerCertificate=True;Connect Timeout=1;ConnectRetryCount=0");
    inaccessible.Open();
}
catch (SqlException) { connectionFailed = true; }
Check(connectionFailed, "SqlClient handles unavailable server on current platform");

AppBuilder.Configure<App>().UseSkia().WithInterFont()
    .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false }).SetupWithoutStarting();
var window = new MainWindow();
T Find<T>(string name) where T : Control => window.FindControl<T>(name)!;
void Field(string name, object value) => typeof(MainWindow).GetField(name, BindingFlags.NonPublic | BindingFlags.Instance)!.SetValue(window, value);
void Call(string name) => typeof(MainWindow).GetMethod(name, BindingFlags.NonPublic | BindingFlags.Instance)!.Invoke(window, null);
void Click(string content) => window.GetVisualDescendants().OfType<Button>().Single(x => Equals(x.Content, content))
    .RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
void Capture(string name)
{
    if (!args.Contains("--capture")) return;
    Dispatcher.UIThread.RunJobs();
    AvaloniaHeadlessPlatform.ForceRenderTimerTick();
    using var frame = window.CaptureRenderedFrame();
    frame!.Save(Path.Combine(Directory.GetCurrentDirectory(), name + ".png"));
}
// Сначала проверяем штатное отсутствие настроек, без сетевых обращений.
Environment.SetEnvironmentVariable("CONTACT_MANAGER_SQL", "Server=;Database=;");
window.Show(); Dispatcher.UIThread.RunJobs();
Check(!Find<Control>("EditorArea").IsEnabled && Find<TextBlock>("StatusText").Text!.Contains("Укажите"), "invalid settings handled without crash");
Capture("lab2-connection");

// Локальная модель проверяется без имитации SQL Server: прямо создаём снимок DataTable.
var table = ContactRepository.CreateTable();
var first = new Contact(Guid.NewGuid(), "Анна Смирнова", "Коллеги", "Средняя", false, true, true, new byte[8]);
var initial = table.NewRow(); ContactRepository.WriteRow(initial, first); initial["Version"] = first.Version; table.Rows.Add(initial); table.AcceptChanges();
Field("isReady", false); Find<ComboBox>("DataModeBox").SelectedIndex = 1; Field("isReady", true);
Field("table", table); Field("loaded", true); Field("disconnected", true);
Call("RebuildList"); Call("UpdateControls");
Find<ListBox>("ContactsList").SelectedIndex = 0;
Check(Find<TextBox>("FullNameBox").Text == first.FullName && Equals(Find<Button>("SaveButton").Content, "Сохранить изменения"), "selection opens editor");
Find<TextBox>("FullNameBox").Text = "Анна Петрова";
Click("Сохранить изменения");
Check(initial.RowState == DataRowState.Modified && (string)initial["FullName"] == "Анна Петрова", "update staged in DataTable");
Check(!Find<ComboBox>("DataModeBox").IsEnabled && !Find<Button>("RefreshButton").IsEnabled, "pending changes block mode switch and refresh");
Capture("lab2-pending");
window.Close();
Check(window.IsVisible, "pending changes prevent accidental close");
Click("Отменить изменения");
Check(initial.RowState == DataRowState.Unchanged && (string)initial["FullName"] == first.FullName, "RejectChanges restores original values");
Click("Добавить контакт");
Check(Find<TextBlock>("NameError").IsVisible && table.Rows.Count == 1, "empty name rejected");
Find<TextBox>("FullNameBox").Text = "  Иван   Петров  ";
Click("Добавить контакт");
Check(table.Rows.Count == 2 && table.Rows[1].RowState == DataRowState.Added && (string)table.Rows[1]["FullName"] == "Иван Петров", "insert staged and whitespace normalized");
Find<ListBox>("ContactsList").SelectedIndex = 0;
Click("Удалить выбранный");
Check(initial.RowState == DataRowState.Deleted, "delete staged");
Click("Отменить изменения");
Check(table.Rows.Count == 1 && initial.RowState == DataRowState.Unchanged, "batch cancellation restores deleted and removes added rows");
window.Close();
Console.WriteLine("SQL Server integration NOT RUN. Use --integration with a configured server.");
