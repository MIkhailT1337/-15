-- Выполнить под администратором после 01-schema.sql.
-- Заменить значение только в строке @Password, не хранить готовый файл в Git.
USE master;
DECLARE @Password nvarchar(128) = N'REPLACE_WITH_STRONG_PASSWORD';
IF @Password = N'REPLACE_' + N'WITH_STRONG_PASSWORD'
    THROW 50002, N'Сначала задайте пароль в переменной @Password.', 1;
IF SUSER_ID(N'contact_app') IS NULL
BEGIN
    DECLARE @Sql nvarchar(max) = N'CREATE LOGIN contact_app WITH PASSWORD=' + QUOTENAME(@Password, '''') + N', CHECK_POLICY=ON;';
    EXEC sys.sp_executesql @Sql;
END;
-- В одном пакете: THROW выше прекращает выполнение, пользователя с заглушкой не будет.
USE ContactManagerDb;
IF DATABASE_PRINCIPAL_ID(N'contact_app') IS NULL
    CREATE USER contact_app FOR LOGIN contact_app;
ALTER ROLE ContactManagerAppRole ADD MEMBER contact_app;
