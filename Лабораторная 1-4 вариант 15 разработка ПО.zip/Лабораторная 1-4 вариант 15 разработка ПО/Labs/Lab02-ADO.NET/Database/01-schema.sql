-- Выполнить под администратором SQL Server. Повторный запуск не удаляет данные.
USE master;
GO
IF DB_ID(N'ContactManagerDb') IS NULL CREATE DATABASE ContactManagerDb;
GO
USE ContactManagerDb;
GO
IF OBJECT_ID(N'dbo.Contacts', N'U') IS NULL
CREATE TABLE dbo.Contacts (
    Id uniqueidentifier NOT NULL CONSTRAINT PK_Contacts PRIMARY KEY,
    FullName nvarchar(100) NOT NULL,
    Category nvarchar(30) NOT NULL,
    Importance nvarchar(10) NOT NULL,
    HasCar bit NOT NULL,
    LikesSport bit NOT NULL,
    LikesIT bit NOT NULL,
    Version rowversion NOT NULL,
    CONSTRAINT CK_Contacts_Name CHECK (LEN(LTRIM(RTRIM(FullName))) >= 3 AND CHARINDEX(N' ', LTRIM(RTRIM(FullName))) > 1),
    CONSTRAINT CK_Contacts_Category CHECK (Category IN (N'Друзья', N'Коллеги', N'Родственники')),
    CONSTRAINT CK_Contacts_Importance CHECK (Importance IN (N'Высокая', N'Средняя', N'Низкая'))
);
GO
CREATE OR ALTER FUNCTION dbo.ImportanceRank(@Importance nvarchar(10))
RETURNS int WITH SCHEMABINDING
AS
BEGIN
    RETURN CASE @Importance WHEN N'Высокая' THEN 1 WHEN N'Средняя' THEN 2 ELSE 3 END;
END;
GO
CREATE OR ALTER VIEW dbo.ContactOverview
AS
SELECT Id, FullName, Category, Importance, HasCar, LikesSport, LikesIT, Version,
       dbo.ImportanceRank(Importance) AS ImportanceRank
FROM dbo.Contacts;
GO
CREATE OR ALTER PROCEDURE dbo.ContactList
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, FullName, Category, Importance, HasCar, LikesSport, LikesIT, Version
    FROM dbo.ContactOverview ORDER BY ImportanceRank, FullName, Id;
END;
GO
-- NOCOUNT OFF нужен SqlDataAdapter для контроля количества обновлённых строк.
CREATE OR ALTER PROCEDURE dbo.ContactInsert
    @Id uniqueidentifier,
    @FullName nvarchar(100),
    @Category nvarchar(30),
    @Importance nvarchar(10),
    @HasCar bit,
    @LikesSport bit,
    @LikesIT bit
AS
BEGIN
    SET NOCOUNT OFF;
    INSERT dbo.Contacts(Id, FullName, Category, Importance, HasCar, LikesSport, LikesIT)
    VALUES(@Id, @FullName, @Category, @Importance, @HasCar, @LikesSport, @LikesIT);
END;
GO
CREATE OR ALTER PROCEDURE dbo.ContactUpdate
    @Id uniqueidentifier,
    @FullName nvarchar(100),
    @Category nvarchar(30),
    @Importance nvarchar(10),
    @HasCar bit,
    @LikesSport bit,
    @LikesIT bit,
    @Version binary(8)
AS
BEGIN
    SET NOCOUNT OFF;
    UPDATE dbo.Contacts SET FullName=@FullName, Category=@Category, Importance=@Importance,
        HasCar=@HasCar, LikesSport=@LikesSport, LikesIT=@LikesIT
    WHERE Id=@Id AND Version=@Version;
    IF @@ROWCOUNT = 0 THROW 50001, N'Контакт изменён или удалён другим пользователем. Обновите список.', 1;
END;
GO
CREATE OR ALTER PROCEDURE dbo.ContactDelete
    @Id uniqueidentifier,
    @Version binary(8)
AS
BEGIN
    SET NOCOUNT OFF;
    DELETE dbo.Contacts WHERE Id=@Id AND Version=@Version;
    IF @@ROWCOUNT = 0 THROW 50001, N'Контакт изменён или удалён другим пользователем. Обновите список.', 1;
END;
GO
IF DATABASE_PRINCIPAL_ID(N'ContactManagerAppRole') IS NULL
    CREATE ROLE ContactManagerAppRole AUTHORIZATION dbo;
GO
GRANT EXECUTE ON OBJECT::dbo.ContactList TO ContactManagerAppRole;
GRANT EXECUTE ON OBJECT::dbo.ContactInsert TO ContactManagerAppRole;
GRANT EXECUTE ON OBJECT::dbo.ContactUpdate TO ContactManagerAppRole;
GRANT EXECUTE ON OBJECT::dbo.ContactDelete TO ContactManagerAppRole;
-- Прямые SELECT/INSERT/UPDATE/DELETE таблицы роли не выдаются.
GO
